"""心／锁冥／守岸人队伍的首发协调、守岸人补能与交锁流程。

本脚本区分整场首发保证和每次驻场进度。技能与切人的结果均以当前 HUD、
连续冷却或资源消耗证据确认；输入发送和固定等待不能代替成功证据。
R 补能窗口设有独立截止点；协奏未满则继续留场，禁止超时未满交棒。
最后一次 Q 发出后须直接发送数字切人键，重试交接时不重复声骸流程。
"""

import math
import time

from src.char.ShoreKeeper import ShoreKeeper as NativeShoreKeeper


class _BreakReady(Exception):
    """先退出当前普攻／重击／闪避动作，再执行处决。"""


class ShoreKeeper(NativeShoreKeeper):
    """保证守岸人首发，并用有限补能、真实资源快照把本轮交给锁冥。

    首发确认可被其他队友入口调用，避免框架随机让心或锁冥先执行动作。
    本次驻场依次准备入场、补能、尝试 R、补协奏与交场；未确认的 R 或
    数字切人保留恢复凭据，下次先核实该步骤，不从头重放已发送动作。
    """

    # 修订号只服务于既有日志定位；全部时间常量均以秒计，资源阈值为 0～1。
    CODE_REVISION = '2026-10-25-break-guard-21'
    # 直接采用心汐守时序，不再额外加收招／稳定停顿。
    # 变奏入场稳定时间与普通入场补普攻时间分开，后者遇满协奏／满回路可提前停。
    INTRO_SETTLE = 0.35
    OPENING_NORMAL_TIME = 1.38
    ATTACK_HOLD = 0.06
    ATTACK_INTERVAL = 0.12
    RESONANCE_SETTLE = 1.43
    # 心汐守宏 SK_L_CON_EVERY / R_BUILD_SLICE：资源识别与连点分开，
    # 补能最多连打一小段，期间资源够了便提前停，不把固定 A 数当成完成。
    RESOURCE_OBSERVE_INTERVAL = 0.15
    NORMAL_BUILD_SLICE = 0.60
    # 重击输入上限不代表成功；松键后还须看到回路消耗，成功才接向前闪避。
    HEAVY_MIN_HOLD = 0.10
    HEAVY_TIMEOUT = 1.60
    HEAVY_ACTION_BUDGET = 2.40
    # 向前闪避的方向预按、右键保持、方向尾段与动作恢复时间。
    DODGE_DIRECTION_LEAD = 0.05
    DODGE_HOLD = 0.07
    DODGE_DIRECTION_TAIL = 0.05
    DODGE_SETTLE = 0.25
    # 连续帧确认分别处理协奏、回路和 CD；轮询间隔只是观察频率，不是完成判据。
    POLL_INTERVAL = 0.03
    CON_CONFIRM_FRAMES = 3
    FORTE_CONFIRM_FRAMES = 2
    CD_CONFIRM_FRAMES = 2
    CD_CONFIRM_TIMEOUT = 0.50
    # 技能补按节流与有限 Q 短按次数；Q 只记已尝试，不额外检查声骸效果。
    SKILL_RETRY_INTERVAL = 0.06
    ECHO_RETRIES = 3
    ECHO_HOLD = 0.05
    # R 启动等待和动画恢复等待各自限时；最短动画时间防止中途 HUD 闪回抢切。
    LIBERATION_START_TIMEOUT = 1.80
    # 最后一次 R 发键后的结果观察窗口；截止后不再补按，仍接收 CD／动画证据。
    LIBERATION_START_CONFIRM = 0.40
    LIBERATION_ANIMATION_MIN = 2.40
    LIBERATION_ANIMATION_TIMEOUT = 6.00
    ACTION_RECOVERY_GUARD = .60
    RESULT_RESTORE_TIMEOUT = 3.00
    # 用户要求满协奏显示后留一点送达时间。只在准备首个切人键前等待，
    # 随后取新帧再核实；不能把等待本身当满值，也不能放到 Q 与数字键之间。
    FULL_CON_SWITCH_SETTLE = .20
    HUD_CONFIRM_FRAMES = 2
    # R 前从既定协奏阈值开始争取施放；满协奏后只再给有限补能宽限。
    LIBERATION_MIN_CON = 0.80
    FULL_CON_ENERGY_GRACE = 3.00
    # 这些窗口限制争取 R 的时间，不再批准未满协奏切人；满协奏是交棒硬条件。
    ENERGY_BUILD_TIMEOUT = 8.00
    CONCERTO_RESCUE_TIMEOUT = 4.00
    WORK_SLICE = 8.00
    # 入场保护允许动画 HUD 暂缺；切人时间片超时保留交棒，后续只补数字键。
    INTRO_TIMEOUT = 6.00
    SWITCH_TIMEOUT = 2.50
    SWITCH_RETRY_INTERVAL = 0.05

    def __init__(self, *args, **kwargs):
        """初始化驻场和整场首发两组状态，保留原生角色初始化与修订日志。"""
        super().__init__(*args, **kwargs)
        self._clear_visit()
        self._reset_opening()
        self.logger.info(f'心锁守代码修订：ShoreKeeper {self.CODE_REVISION}')

    def _reset_opening(self):
        """重置整场首发保证；普通 switch_out 不调用它，以免每次重抢首发。"""
        # 保存首次切人前的源角色与协奏；HUD 更新落后于资源消耗时仍能
        # 正确还原是否存在变奏，不能用后续重试帧覆盖这份快照。
        self._opening_done = False
        self._opening_source = None
        self._opening_source_con = 0.0
        self._opening_with_intro = False
        self._opening_sent_at = None
        # guard 只表示输入后允许等待的保护，不等于已确认守岸人在场。
        self._opening_guard_until = 0.0

    def _clear_visit(self):
        """清理一次驻场进度，保留整场首发是否完成的状态。"""
        # 入场与 R 状态：_visit_liberated 只在发键后取得连续 CD 证据时置真。
        self._visit_started = None
        self._entry_done = False
        self._visit_liberated = False
        self._liberation_pending = None
        self._liberation_ready_at = None
        self._post_liberation_full_at = None
        # Q 次数在一次驻场内累计；完成仅表示既定短按尝试结束。
        self._echo_done = False
        self._echo_attempts = 0
        # 满协奏的首次时间锚与连续帧计数分开，短暂掉到 99% 不能重开补能宽限。
        self._full_con_since = None
        self._con_hits = 0
        self._full_switch_ready_at = None
        self._pending_wait_con_logged = False
        self._next_resonance = 0.0
        self._next_liberation = 0.0
        self._intro_guard_until = 0.0
        self._team_entry_guard_until = 0.0
        self._action_recovery_until = 0.0
        # 切人发出前冻结的目标／源资源条件；恢复时不能重读已消耗后的协奏。
        self._pending_target = None
        self._pending_switch_until = 0.0
        self._pending_full_con = False
        self._pending_source_con = 0.0
        self._con_ring_snapshot = None
        self._strict_con_wait_logged = False
        self._short_budget_logged = False
        self._r_wait_logged = False
        # 跨调度的补能和补协奏起点，保证所有动作共享有限剩余预算。
        self._energy_started = None
        self._con_rescue_since = None
        self.check_f_on_switch = False

    def reset_state(self):
        """框架新战斗重置时，同时清理驻场步骤与首发保证。"""
        super().reset_state()
        self._clear_visit()
        self._reset_opening()

    def switch_out(self, con_full=False):
        """原生逻辑处理离场资源后清驻场，不重新激活本场的首发抢场。"""
        super().switch_out(con_full=con_full)
        self._clear_visit()

    def skip_combat_check(self):
        """接住队友交场至首次调度前的有限保护，再由本次入场步骤接管。"""
        return (time.time() < max(self._intro_guard_until, getattr(self, '_team_entry_guard_until', 0.0),
                                 getattr(self, '_action_recovery_until', 0.0))
                or self.opening_guard_active())

    def opening_guard_active(self):
        """供三人共同查询首发输入后的短期保护，过期后自动恢复普通检查。"""
        return time.time() < self._opening_guard_until

    def perform(self):
        """先满足守岸人首发保证，再进入原生 perform 调用本队动作。"""
        try:
            if self.ensure_opening(self):
                return super().perform()
        except _BreakReady:
            suo = self._team_suoming()
            execute = getattr(suo, 'perform_ready_break', None)
            if callable(execute):
                return execute(self)

    def _team_suoming(self):
        """查找本队的公共处决协调器，不依赖槽位顺序。"""
        return next((char for char in self.task.chars if char is not None
                     and char.char_name == 'char_suoming'
                     and callable(getattr(char, 'break_ready', None))), None)

    def check_combat(self):
        """处决提示就绪时，先让持键动作正常退出，再按 F。"""
        suo = self._team_suoming()
        probe = getattr(suo, 'break_ready', None)
        if callable(probe) and probe(self):
            raise _BreakReady()
        return super().check_combat()

    def ensure_opening(self, caller, *, commit=True, check_combat=True):
        """新战斗先交场给守岸人；框架的战前／战后切奶也走相同确认。

        commit=False 只完成眼前切奶，不消费下一场首发保证；check_combat
        控制战前／战后入口是否执行战斗检查。首次交场确认时，仅对守岸人
        自己返回 True，让发起调用的队友停下并交还调度；首发保证完成后，
        后续调用直接通过，不再阻挡正常轮转。
        """
        if self._opening_done:
            return True
        start, last_send = time.time(), -1.0
        previous, hits, con_hits = None, 0, 0
        while time.time() - start < self.SWITCH_TIMEOUT:
            self.task.next_frame()
            if check_combat:
                self.check_combat()
            visible, index, _ = self.task.in_team()
            target = next((c for c in self.task.chars if c is not None and c.index == index), None)
            if not visible or target is None:
                previous, hits, con_hits = None, 0, 0
            else:
                hits = hits + 1 if index == previous else 1
                con_hits = con_hits if index == previous else 0
                previous = index
                if target is self and hits >= self.HUD_CONFIRM_FRAMES:
                    # 目标槽位稳定才提交源离场和变奏；仅发送数字键尚不够。
                    # 热重载保留旧对象引用，离场记账必须落到当前队伍实例。
                    saved_source = self._opening_source
                    source = next((c for c in self.task.chars
                                   if c is not None and saved_source is not None
                                   and c.index == saved_source.index
                                   and c.char_name == saved_source.char_name), None)
                    if source is not None:
                        full = self._opening_with_intro
                        source.current_con = self._opening_source_con
                        source.switch_out(con_full=full)
                        self.has_intro = full
                        self.has_sub_dps_intro = full and source.is_sub_dps
                        self.last_switch_in_time = self._opening_sent_at
                        if full:
                            source.last_outro_time = time.time()
                            self.add_freeze_duration(time.time(), self.intro_motion_freeze_duration, -100)
                    elif saved_source is not None:
                        # 已确认守岸人在场，但来源已不存在，不能补造资源或变奏。
                        self.has_intro = self.has_sub_dps_intro = False
                        self.logger.warning('首发来源已不在当前队伍，仅同步实际在场角色')
                    for char in self.task.chars:
                        if char is not None:
                            char.is_current_char = char is self
                    self._opening_source = None
                    self._opening_sent_at = None
                    self._opening_guard_until = 0.0
                    # 战后自动切奶不能消耗下一场的首发保证。
                    self._opening_done = commit
                    return caller is self
                if target is not self:
                    try:
                        con = float(self.task.get_current_con())
                    except (TypeError, ValueError):
                        con = float('nan')
                    valid = math.isfinite(con) and 0 <= con <= 1
                    # 非满协奏可按真实值直接切；满协奏要多帧确认，避免
                    # 单次 OCR 满值导致伪造变奏和延奏冻结记账。
                    con_hits = con_hits + 1 if valid and con == 1 else 0
                    if (hits >= self.HUD_CONFIRM_FRAMES and valid
                            and (con < 1 or con_hits >= self.CON_CONFIRM_FRAMES)
                            and time.time() - last_send >= self.SWITCH_RETRY_INTERVAL):
                        # 协奏消耗可能先于槽位 HUD 更新，不能让重试覆盖已捕获的变奏。
                        if (self._opening_source is None
                                or self._opening_source.index != target.index
                                or self._opening_source.char_name != target.char_name):
                            self._opening_source_con = con
                            self._opening_with_intro = con == 1
                        # 同身份热重载只更新引用，不能覆盖发键前的资源快照。
                        self._opening_source = target
                        self._opening_sent_at = time.time()
                        if time.time() >= self._opening_guard_until:
                            self._opening_guard_until = time.time() + self.INTRO_TIMEOUT
                        self.task.send_key(self.index + 1)
                        last_send = time.time()
            self.sleep(self.POLL_INTERVAL, check_combat=check_combat)
        self.logger.warning('守岸人首发切换尚未确认，其他角色暂不执行动作，下次继续核实')
        return False

    def _reconcile_visible_actor(self):
        """意外切人后同步真实槽位，避免调度永远重复调用旧守岸人。

        连续看见其他有效槽位才接受切换。没有受控交棒的源资源快照时，
        同时清除双方变奏推断；画面暂时不可见不会被当作其他角色在场。
        """
        visible, index, _ = self.task.in_team()
        target = next((c for c in self.task.chars if c is not None and c.index == index), None)
        if not visible or target is None or target is self:
            return False
        for _ in range(self.HUD_CONFIRM_FRAMES - 1):
            self.sleep(self.POLL_INTERVAL)
            self.task.next_frame()
            self.check_combat()
            current_visible, current_index, _ = self.task.in_team()
            if not current_visible or current_index != index:
                return False
        for char in self.task.chars:
            if char is not None:
                char.is_current_char = char is target
        self.has_intro = self.has_sub_dps_intro = False
        target.has_intro = target.has_sub_dps_intro = False
        self._clear_visit()
        self.logger.warning('检测到其他角色稳定在场，按实际槽位交还调度，不推测变奏')
        return True

    def _hud_active(self):
        """使用真实队伍 HUD 验证守岸人在场，作为本角色输入和资源读取的前提。"""
        in_team, index, _ = self.task.in_team()
        return bool(in_team and index == self.index)

    def _observe_con(self, *, advance_frame=True):
        """读取归一化协奏；已推进当前帧的连点段可复用该帧，未知值不当作资源。"""
        if advance_frame:
            self.task.next_frame()
        self.check_combat()
        if not self._hud_active():
            self._con_hits = 0
            self._full_switch_ready_at = None
            return None
        try:
            value = float(self.task.get_current_con())
        except (TypeError, ValueError):
            self._con_hits = 0
            self._full_switch_ready_at = None
            return None
        if not math.isfinite(value) or not 0 <= value <= 1:
            self._con_hits = 0
            self._full_switch_ready_at = None
            return None
        self.current_con = value
        self._con_hits = self._con_hits + 1 if value == 1 else 0
        if value != 1:
            self._full_switch_ready_at = None
        if (value == 1 and self._liberation_ready_at is not None
                and self._post_liberation_full_at is None):
            self._post_liberation_full_at = time.time()
            self.logger.info(f'守岸人：R 后首次读到满协奏，尚待连续确认；'
                             f'距 HUD 恢复 {self._post_liberation_full_at - self._liberation_ready_at:.3f}s')
        return value

    def _capture_con_ring_snapshot(self):
        """只缓存交棒前的源裁图与颜色；图像诊断和截图请求留到切人已确认后。"""
        try:
            index = self.task._ensure_ring_index()
            box = self.task.get_con_box()
            crop = box.crop_frame(self.task.frame)[:, :, :3].copy()
            self._con_ring_snapshot = (crop, index, (box.x, box.y, box.width, box.height))
        except (AttributeError, ValueError, TypeError, IndexError) as exc:
            self._con_ring_snapshot = None
            self.logger.info(f'守岸人：协奏诊断裁图不可读：{type(exc).__name__}: {exc}')

    def _save_con_ring_snapshot(self, snapshot):
        """切人确认后检查并保存已缓存的源色环，结果仅供诊断。

        原生会做闭运算容忍渐变与抗锯齿；原始掩膜没有孔洞不一定就是
        未满。缺少实际校准样本时不把此观察当作可用的满／未满判据，
        避免新加条件导致实际已满却永久留场。
        """
        if snapshot is None:
            return
        crop, index, bounds = snapshot
        try:
            import cv2
            import numpy as np
            from src.task.BaseCombatTask import con_colors
            if not crop.size or not 0 <= index < len(con_colors):
                self.logger.info('守岸人：缓存的协奏颜色或画面不可读')
                return
            color = con_colors[index]
            lower = np.array([color['b'][0], color['g'][0], color['r'][0]], dtype=np.uint8)
            upper = np.array([color['b'][1], color['g'][1], color['r'][1]], dtype=np.uint8)
            h, w = crop.shape[:2]
            center = (w // 2, h // 2)
            annulus = np.zeros((h, w), dtype=np.uint8)
            cv2.circle(annulus, center, int(math.ceil(h * .42261)), 255, -1)
            cv2.circle(annulus, center, int(h * .35119), 0, -1)
            mask = cv2.bitwise_and(cv2.inRange(crop, lower, upper), annulus)
            contours, hierarchy = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
            closed = False
            if hierarchy is not None:
                for contour, relation in zip(contours, hierarchy[0]):
                    if (relation[3] >= 0 and cv2.contourArea(contour) >= math.pi * (h * .25) ** 2
                            and cv2.pointPolygonTest(contour, center, False) >= 0):
                        closed = True
                        break
            self.logger.info(f'守岸人：切人后复核交棒前缓存色环；原始闭环={closed}，颜色={index}，框={bounds}')
        except Exception as exc:
            if not isinstance(exc, (ImportError, AttributeError, ValueError, TypeError, IndexError)) and type(exc).__module__ != 'cv2':
                raise
            self.logger.info(f'守岸人：缓存色环诊断未知：{type(exc).__name__}: {exc}')
        self.task.screenshot(f'keeper_concerto_{int(time.time())}', frame=crop)

    def _confirm_full_con(self):
        """从零累计独立的连续满协奏帧，给即将创建的交棒提供资源证据。"""
        self._con_hits = 0
        for _ in range(self.CON_CONFIRM_FRAMES):
            if self._observe_con() != 1:
                return False
            if self._con_hits < self.CON_CONFIRM_FRAMES:
                self.sleep(self.POLL_INTERVAL)
        return self._con_hits >= self.CON_CONFIRM_FRAMES

    def _settle_full_con_before_switch(self):
        """已有连续满值后短暂稳定，再用新画面确认首个切人键的资格。

        任何未满、未知或离场都会撤销本次稳定凭据。暂停／代码重载后的旧
        调用栈不能直接发键；Q 与数字键仍保持相邻。稳定截止只建立一次，
        不是每次恢复调用都重新加200ms。
        """
        ready_at = getattr(self, '_full_switch_ready_at', None)
        if ready_at is None:
            ready_at = time.time() + self.FULL_CON_SWITCH_SETTLE
            self._full_switch_ready_at = ready_at
        self._action_recovery_until = max(getattr(self, '_action_recovery_until', 0.0),
                                          ready_at + self.ACTION_RECOVERY_GUARD)
        remaining = ready_at - time.time()
        if remaining > 0:
            self.sleep(remaining, check_combat=False)
        if not any(char is self for char in self.task.chars):
            return False
        value = self._observe_con()
        if value != 1 or not self._hud_active():
            self._full_switch_ready_at = None
            self._con_hits = 0
            self.logger.info(f'守岸人：满协奏短暂稳定后复核未通过（读数={value}），继续补满，不发切人键')
            return False
        self.logger.info(f'守岸人：满协奏保留 {self.FULL_CON_SWITCH_SETTLE:.2f}s 后新帧复核仍满，准备 Q 交锁')
        return True

    def _confirm_cd(self, name):
        """在有限窗口内确认指定技能连续处于冷却；丢失自身 HUD 即停止确认。"""
        start, hits = time.time(), 0
        while time.time() - start < self.CD_CONFIRM_TIMEOUT:
            self.task.next_frame()
            self.check_combat()
            if not self._hud_active():
                return False
            hits = hits + 1 if self.task.has_cd(name) else 0
            if hits >= self.CD_CONFIRM_FRAMES:
                return True
            self.sleep(self.POLL_INTERVAL)
        return False

    def _prepare_entry(self):
        """等待真实入场 HUD，再按变奏或普通入场选择一次准备动作。

        变奏稳定等待锚定实际切入时间，过旧或异常时间才回落驻场起点。
        普通入场只在 R 前协奏不足且未满回路时补普攻；正常打完起手
        窗口直接接 E，资源提前够则交回主分支，不再插一轮完整技能识别。
        """
        if self._visit_started is None:
            self._visit_started = time.time()
            if self.has_intro:
                self._intro_guard_until = time.time() + self.INTRO_TIMEOUT
        start = time.time()
        while not self._hud_active() and time.time() - start < self.INTRO_TIMEOUT:
            self.task.next_frame()
            self.sleep(self.POLL_INTERVAL, check_combat=not self.has_intro)
        if not self._hud_active():
            return False
        if self.has_intro:
            anchor = self.last_switch_in_time
            if not 0 <= time.time() - anchor <= self.INTRO_TIMEOUT:
                anchor = self._visit_started
            self.sleep(max(0, anchor + self.INTRO_SETTLE - time.time()), check_combat=False)
        else:
            con = self._observe_con()
            if con is None:
                return False
            limit = self.LIBERATION_MIN_CON if self.task.use_liberation else 1.0
            if con < limit and not self.is_mouse_forte_full():
                # 一旦开始起手输入便保存步骤；HUD 暂缺／暂停恢复不能再放一遍 3A。
                self._entry_done = True
                self._intro_guard_until = 0.0
                normal_started = time.time()
                result = self._normal_for(self.OPENING_NORMAL_TIME, con_limit=limit)
                self.logger.info(f'守岸人：起手普攻结束，原因={result}，耗时 {time.time() - normal_started:.3f}s')
                if result == 'hud':
                    return False
                if result == 'complete':
                    if self._energy_started is None:
                        self._energy_started = time.time()
                    self._cast_resonance()
        self._intro_guard_until = 0.0
        self._team_entry_guard_until = 0.0
        self._entry_done = True
        return True

    def _normal_for(self, duration, *, con_limit=1.0, stop_on_forte=True):
        """连点按发送时刻排程，资源按独立节奏读，够用或离场便停。

        心汐守用 0.15s 节流昂贵的协奏识别，日月守用 0.60s 补能小段；
        每次准备补 A 先核验自身 HUD 和满回路，再按节流读取协奏；满回路
        只停止短按，真正重击仍由 _forte_heavy 连续两帧确认。连点次数不
        等于实际普攻段数，不用固定三次点击替代资源判据或原有时间窗。
        仅剩余预算已不足一次完整重击时可关闭满回路停 A，继续短按补能，
        避免“预算不准重击、满回路又不准 A”的无输入空转。
        所有等待均落在已有输入周期内，不额外垫收招时间。
        """
        start = time.time()
        deadline, next_attack = start + duration, start
        next_observe = start + self.RESOURCE_OBSERVE_INTERVAL
        while time.time() < deadline:
            self.task.next_frame()
            self.check_combat()
            if not self._hud_active():
                return 'hud'
            if time.time() >= deadline:
                break
            # 回路指示先于昂贵的协奏识别检查，满了就不再追加下一下 A。
            if stop_on_forte and self.is_mouse_forte_full():
                return 'forte'
            if time.time() >= next_observe:
                con = self._observe_con(advance_frame=False)
                next_observe = time.time() + self.RESOURCE_OBSERVE_INTERVAL
                if con is None:
                    return 'hud'
                if con >= con_limit:
                    return 'con'
            now = time.time()
            if now >= deadline:
                break
            if deadline - now < self.ATTACK_HOLD:
                self.sleep(max(0, deadline - time.time()))
                break
            if now >= next_attack:
                sent_at = self._attack()
                if sent_at is False:
                    return 'hud'
                next_attack = sent_at + self.ATTACK_INTERVAL
            # 不追发识别耗时期间错过的 A，也不让末次输入越过本段截止点。
            wake_at = min(deadline, next_observe, next_attack)
            self.sleep(max(0, wake_at - time.time()))
        return 'complete'

    def _attack(self):
        """核对自身 HUD 后普攻，返回实际发键时刻供调用处节流，离场返回 False。"""
        self.check_combat()
        if not self._hud_active() or not any(char is self for char in self.task.chars):
            return False
        # 心汐守实机备注：BaseChar.click 强制 10ms，改用 task.click 保留 60ms 按住。
        sent_at = time.time()
        self.task.click(down_time=self.ATTACK_HOLD)
        return sent_at

    def _resonance_followup(self, cast_at):
        """以 E 的发送时刻为锚补普攻，避免相对 sleep 叠加漂移。

        截止点包含已花在 E 成功确认上的时间；剩余不足一个普攻周期时
        只等待剩余段，不再开启会跨越该动作窗口的新普攻。
        """
        deadline = cast_at + self.RESONANCE_SETTLE
        while time.time() < deadline:
            self.task.next_frame()
            self.check_combat()
            if not self._hud_active():
                return
            left = deadline - time.time()
            if left >= self.ATTACK_INTERVAL:
                self._attack()
                self.sleep(self.ATTACK_INTERVAL - self.ATTACK_HOLD)
            elif left > 0:
                self.sleep(left)

    def _cast_resonance(self):
        """在有限输入窗口内尝试 E，发键后取得连续 CD 证据才记录使用并接普攻。"""
        if not self._hud_active() or not self.resonance_available():
            return False
        self._next_resonance = time.time() + self.SKILL_RETRY_INTERVAL
        start, last_send, cast_at = time.time(), -1.0, None
        while time.time() - start < 0.60:
            self.task.next_frame()
            self.check_combat()
            if not self._hud_active():
                return False
            if self.task.has_cd('resonance'):
                if last_send < 0:
                    # 进入方法前已处于冷却不是本次发送成功，不能补记一次 E。
                    return False
                if self._confirm_cd('resonance'):
                    self.record_resonance_use()
                    confirmed_after = time.time() - cast_at
                    self._resonance_followup(cast_at)
                    self.logger.info(f'守岸人：E 已确认，后续普攻结束；CD 确认耗时 {confirmed_after:.3f}s，'
                                     f'距 E 首键 {time.time() - cast_at:.3f}s')
                    return True
            elif time.time() - last_send >= self.SKILL_RETRY_INTERVAL:
                # 社区 1.43s 是按 E 的发送时刻标定，补按和 CD 识别不能后移锚点。
                last_send = time.time()
                first_send = cast_at is None
                if first_send:
                    cast_at = last_send
                self.send_resonance_key()
                if first_send:
                    self.logger.info('守岸人：E 首次发键')
            self.sleep(self.POLL_INTERVAL)
        self.logger.warning('守岸人 E 未确认进入冷却，保留当前步骤后续重试')
        return False

    def _forte_confirmed(self):
        """连续核实满回路与自身 HUD，防止单帧亮条触发重击。"""
        for _ in range(self.FORTE_CONFIRM_FRAMES):
            self.task.next_frame()
            self.check_combat()
            if not self._hud_active() or not self.is_mouse_forte_full():
                return False
            self.sleep(self.POLL_INTERVAL)
        return True

    def _forte_heavy(self):
        """确认满回路后有限长按，松键后确认回路消耗，成功才执行向前闪避。"""
        if not self._forte_confirmed():
            return False
        start = time.time()
        try:
            self.task.mouse_down()
            while time.time() - start < self.HEAVY_TIMEOUT:
                self.task.next_frame()
                self.check_combat()
                if not self._hud_active():
                    break
                if time.time() - start >= self.HEAVY_MIN_HOLD and not self.is_mouse_forte_full():
                    break
                self.sleep(self.POLL_INTERVAL)
        finally:
            # 无论离场、超时还是异常都释放左键，避免输入状态泄漏到后续角色。
            self.task.mouse_up()
        for _ in range(self.FORTE_CONFIRM_FRAMES):
            self.task.next_frame()
            if not self._hud_active() or self.is_mouse_forte_full():
                self.logger.warning('守岸人重击未确认消耗回路，重新识别后补打')
                return False
            self.sleep(self.POLL_INTERVAL)
        consumed_at = time.time()
        self._dodge_forward()
        self.logger.info(f'守岸人：重击消耗已确认，前闪结束；消耗确认耗时 {consumed_at - start:.3f}s，'
                         f'前闪耗时 {time.time() - consumed_at:.3f}s')
        return True

    def _dodge_forward(self):
        """按既定方向与右键时序前闪；嵌套 finally 确保两种输入都能释放。"""
        self.check_combat()
        if not self._hud_active():
            return
        try:
            self.task.send_key_down('w')
            self.sleep(self.DODGE_DIRECTION_LEAD)
            if not self._hud_active():
                return
            try:
                self.task.mouse_down(key='right')
                self.sleep(self.DODGE_HOLD)
            finally:
                self.task.mouse_up(key='right')
            self.sleep(self.DODGE_DIRECTION_TAIL)
        finally:
            self.task.send_key_up('w')
        self.sleep(self.DODGE_SETTLE)

    def _cast_liberation(self, startup_deadline=None, *, ready_checked=False):
        """创建或恢复一次 R，把施放消耗确认与动画恢复确认分别处理。

        startup_deadline 是外层补能／协奏预算给出的绝对截止点；恢复调用
        只能收紧它。返回 False 时若 pending 仍存在，表示动画步骤尚未核实，
        下一次须先恢复，不能重新开始普通动作或把等待上限当作施放成功。
        ready_checked 只复用外层紧邻、同帧且含 CD 的可用性确认；首次发键
        前不再换帧重跑 OCR。发键后仍逐帧确认真实 CD 和动画恢复。
        """
        pending = self._liberation_pending
        if pending is not None and pending['last_send'] < 0:
            # 暂停可能发生在建状态和首键之间；未发键的旧候选不能复用旧 ready。
            previous = pending['startup_deadline']
            if previous is not None:
                startup_deadline = min(previous, startup_deadline) if startup_deadline is not None else previous
            self._liberation_pending = pending = None
            ready_checked = False
        if pending is None:
            if startup_deadline is not None and time.time() >= startup_deadline:
                return False
            if (not self.task.use_liberation or not self._hud_active()
                    or (not ready_checked and not self.liberation_available())):
                return False
            # start 在首次真正发键时重锚，last_send 约束补按节奏；gone_at
            # 仅作动画候选，confirmed 必须由本次发键后的连续 CD 证据建立。
            pending = {'start': time.time(), 'last_send': -1.0, 'gone_at': None,
                       'confirmed': False, 'startup_deadline': startup_deadline}
            self._liberation_pending = pending
        elif startup_deadline is not None:
            # 同一笔 R 的恢复不能获得新预算，取已有和新传入截止点中更早者。
            previous = pending['startup_deadline']
            pending['startup_deadline'] = (min(previous, startup_deadline)
                                           if previous is not None else startup_deadline)
        pending.setdefault('observe_until', pending['start'] + self.LIBERATION_ANIMATION_TIMEOUT
                           + self.RESULT_RESTORE_TIMEOUT)
        start, cd_hits = time.time(), 0
        restored_hits, hud_hits, hud_up_since = 0, 0, None
        self.task.in_liberation = True
        try:
            if pending['last_send'] < 0:
                # 本帧刚确认 R 可用；先发首键，下一帧才进入结果观察，避免
                # 已经 ready 却在发键前额外刷新整栏冷却造成原地停顿。
                sent_at = time.time()
                deadline = pending['startup_deadline']
                if deadline is not None and sent_at >= deadline:
                    self._liberation_pending = None
                    return False
                pending['start'] = pending['last_send'] = sent_at
                pending['observe_until'] = sent_at + self.LIBERATION_ANIMATION_TIMEOUT + self.RESULT_RESTORE_TIMEOUT
                self.send_liberation_key()
                self.logger.info('守岸人：R 首次发键，等待连续 CD 确认')
            # 动画藏 HUD 时 OCR 没有可信 CD，先等 HUD 恢复，再确认冷却。
            while time.time() - start < self.LIBERATION_ANIMATION_TIMEOUT:
                sent_this_frame = False
                self.task.next_frame()
                # 失败依据必须来自末次发键观察窗口之后采到的画面；慢 CD
                # 识别跨过截止，并不能让原本过早的那一帧变成超时证据。
                frame_at = time.time()
                self.check_combat()
                if self._reconcile_visible_actor():
                    return False
                now = time.time()
                animation_anchor = pending['gone_at'] if pending['gone_at'] is not None else pending['start']
                if not self._hud_active():
                    if pending['last_send'] < 0:
                        self._liberation_pending = None
                        return False
                    if pending['gone_at'] is None:
                        pending['gone_at'] = now
                    cd_hits = 0
                    hud_hits = 0
                    hud_up_since = None
                    restored_hits = 0
                else:
                    hud_hits += 1
                    cd = False if pending['confirmed'] else self.task.has_cd('liberation')
                    # 图标有白色像素并不证明能量够；重按共享外层剩余预算，恢复也不能续期。
                    now = time.time()
                    deadline = pending['startup_deadline']
                    if pending['last_send'] >= 0:
                        # 外层剩余预算和 R 自身启动上限同时生效，重按不会
                        # 重置 start，因此不能靠持续识别可用图标无限续期。
                        attempt_end = pending['start'] + self.LIBERATION_START_TIMEOUT
                        deadline = min(deadline, attempt_end) if deadline is not None else attempt_end
                    if (not cd and not pending['confirmed']
                            and (deadline is None or now < deadline)
                            and now - pending['last_send'] >= self.SKILL_RETRY_INTERVAL
                            and self.task.available('liberation', check_color=True, check_cd=False)):
                        # OCR／颜色读取本身可能很慢，必须在真正发键之前再次检查截止点。
                        sent_at = time.time()
                        if deadline is None or sent_at < deadline:
                            pending['gone_at'] = None
                            pending['last_send'] = sent_at
                            sent_this_frame = True
                            self.send_liberation_key()
                    now = time.time()
                    if hud_up_since is None:
                        hud_up_since = now
                    cd_hits = cd_hits + 1 if cd else 0
                if (not pending['confirmed'] and pending['last_send'] >= 0
                        and cd_hits >= self.CD_CONFIRM_FRAMES):
                    # 只在此处记本次驻场 R 已使用；HUD 隐藏、图标变灰或
                    # 输入函数返回都不单独构成确认。
                    pending['confirmed'] = True
                    self._visit_liberated = True
                    self.record_liberation_use()
                    self.logger.info(f'守岸人：R 连续 CD 已确认；距首键 {time.time() - pending["start"]:.3f}s')
                # R 中途会闪回 HUD；施放成功与动画完成必须分别确认。
                if pending['confirmed'] and self._hud_active() and now - animation_anchor >= self.LIBERATION_ANIMATION_MIN:
                    restored_hits += 1
                    if restored_hits >= self.HUD_CONFIRM_FRAMES:
                        # 先扣除真实藏 HUD 区间，再开启独立补协奏窗口；
                        # 重置满协奏连续帧，避免沿用动画前的旧观察结果。
                        if pending['gone_at'] is not None and hud_up_since is not None:
                            self.add_freeze_duration(pending['gone_at'], hud_up_since - pending['gone_at'])
                        self._liberation_pending = None
                        self._liberation_ready_at = time.time()
                        self._con_rescue_since = self._liberation_ready_at
                        self._con_hits = 0
                        self.logger.info(f'守岸人：R 后 HUD 连续恢复，开始核实协奏；'
                                         f'距首键 {self._liberation_ready_at - pending["start"]:.3f}s')
                        return self._hud_active()
                elif not self._hud_active():
                    restored_hits = 0
                deadline = pending['startup_deadline']
                if frame_at >= pending['observe_until']:
                    # 已确认过的 R 消耗保留；期限耗尽只撤销未决动画，不用
                    # 永久等待 HUD／CD，也不能把超时充当开大成功或满协奏。
                    self._liberation_pending = None
                    self._con_hits = 0
                    self._next_liberation = time.time() + self.SKILL_RETRY_INTERVAL
                    self._action_recovery_until = time.time() + self.ACTION_RECOVERY_GUARD
                    self.logger.warning('守岸人：本笔 R 的总观察期限已到，解除未决演出；'
                                        f'消耗已确认={pending["confirmed"]}，按实际协奏继续处理')
                    return False
                startup_expired = ((deadline is not None and now >= deadline)
                                   or (pending['last_send'] >= 0
                                       and now - pending['start'] >= self.LIBERATION_START_TIMEOUT))
                if (not pending['confirmed'] and startup_expired
                        and not sent_this_frame
                        and (pending['last_send'] < 0
                             or frame_at - pending['last_send'] >= self.LIBERATION_START_CONFIRM)
                        and cd_hits == 0
                        and (pending['gone_at'] is None or hud_hits >= self.HUD_CONFIRM_FRAMES)):
                    # 发键前的本帧 CD 不能否定刚发出的 R；最后一按仍有短期结果观察。
                    # 曾经藏过 HUD 只保留候选；自己 HUD 稳定回来仍没有 CD，不能永久续等。
                    self._liberation_pending = None
                    self.logger.warning('守岸人 R 未确认成功，仍按实际协奏状态处理')
                    return False
                self.sleep(self.POLL_INTERVAL)
        finally:
            # pending 可跨调度保留，但框架演出标记不能因异常／超时悬挂。
            self.task.in_liberation = False
        self.logger.warning('守岸人 R 等待上限，保留本次发键／确认凭据，下次先恢复该步骤')
        return False

    def _ensure_echo(self):
        """仅短按，最多三次；最后一次 Q 后直接发切人键，不验证声骸。

        多次调用共享本次驻场尝试次数，切人恢复不再次运行 Q。_echo_done
        只说明计划内的最后一次尝试已准备发出，不能解释为声骸生效证据。
        """
        if self._echo_done:
            return True
        while self._echo_attempts < self.ECHO_RETRIES:
            if not self._hud_active():
                return False
            self._echo_attempts += 1
            if self._echo_attempts == self.ECHO_RETRIES:
                # 只记“已尝试”，不记施放成功；写状态也放在最后一次 Q 之前。
                self._echo_done = True
                self.send_echo_key(down_time=self.ECHO_HOLD)
                return True
            self.send_echo_key(down_time=self.ECHO_HOLD)
        return True

    def _build_energy(self, budget, con):
        """按剩余预算优先消耗满回路，再选择 E 或连续普攻小段。

        E 至少预留发键确认与后续普攻窗口，重击预留完整动作预算；不因
        单次技能看似可用而开启明显超过当前补能／补协奏期限的新动作。
        参考楽山心锁守 2.0.0 的 sk_build_energy：已经满回路时先重击，
        避免补能入口先 E 再 A 把新回路能量挤掉；固定起手的 E→卡点 A 不变。
        """
        deadline = time.time() + max(0, budget)
        if (deadline - time.time() >= self.HEAVY_ACTION_BUDGET and self._hud_active()
                and self.is_mouse_forte_full()
                and deadline - time.time() >= self.HEAVY_ACTION_BUDGET):
            if not self._forte_heavy():
                # 单帧满回路后未通过连续确认，至少恢复短 A，不能只读图空转。
                self._normal_for(max(0.0, min(deadline - time.time(), self.NORMAL_BUILD_SLICE)),
                                 con_limit=1.0, stop_on_forte=False)
            return
        if (budget >= self.RESONANCE_SETTLE + 0.60
                and time.time() >= self._next_resonance and self.resonance_available()
                and deadline - time.time() >= self.RESONANCE_SETTLE + 0.60):
            if not self._cast_resonance():
                # E 被打断／未确认消耗时，至少给实际短 A 一次恢复机会，
                # 不能因为图标仍像可用就每次只重按 E。
                self._normal_for(max(0.0, min(deadline - time.time(), self.NORMAL_BUILD_SLICE)),
                                 con_limit=1.0, stop_on_forte=False)
            return
        remaining = deadline - time.time()
        if self._hud_active() and remaining >= self.ATTACK_INTERVAL:
            # 只在本段开始时低于 80% 才以它为提前停止点；已经达到但 R
            # 暂时没亮时仍可补能，不能因反复遇到同一阈值而只读图空转。
            limit = (self.LIBERATION_MIN_CON if self.task.use_liberation
                     and not self._visit_liberated and con < self.LIBERATION_MIN_CON else 1.0)
            stop_on_forte = remaining >= self.HEAVY_ACTION_BUDGET
            if not stop_on_forte and not getattr(self, '_short_budget_logged', False):
                self._short_budget_logged = True
                self.logger.info(f'守岸人：余量 {remaining:.3f}s 不足完整重击，改用预算内短 A 补能')
            self._normal_for(max(0.0, min(deadline - time.time(), self.NORMAL_BUILD_SLICE)), con_limit=limit,
                             stop_on_forte=stop_on_forte)
        else:
            self.sleep(max(0, deadline - time.time()))

    def _switch_to_suoming(self, source_con=None, *, full_con_confirmed=False):
        """只有真实满协奏才创建交锁；取消所有未满协奏超时交棒入口。

        新交棒先确认资源、保存目标和保护期限，再执行 Q→数字键。已有
        pending 时跳过准备和 Q；目标回执确认原交接，补发数字键前则重读
        仍在场的守岸人协奏，当前未满／未知时只等原回执，不凭旧值补键。
        full_con_confirmed 仅由 do_perform 紧邻的三帧满值路径传入；这次
        观察后没有再发技能，才复用该证据。其他入口从零重新确认三帧。
        """
        if not any(char is self for char in self.task.chars):
            return False
        target = next((c for c in self.task.chars if c is not None and c is not self
                       and (c.char_name == 'char_suoming' or c.name == 'Suoming')), None)
        if target is None:
            if self._pending_target is not None:
                until = getattr(self, '_pending_switch_until', 0.0) or self._intro_guard_until
                if not until:
                    self._pending_switch_until = time.time() + self.INTRO_TIMEOUT
                elif time.time() >= until + self.LIBERATION_START_CONFIRM:
                    self._cancel_switch('目标角色缺失且旧切人票据已到期')
            return False
        if self._pending_target is not None and not getattr(self, '_pending_switch_until', 0.0):
            # 旧代码热重载继承票据时，沿用旧保护截止；不能每次恢复重新给六秒。
            self._pending_switch_until = (self._intro_guard_until if self._intro_guard_until > 0
                                          else time.time() + self.INTRO_TIMEOUT)
        if self._pending_target is not None and not self._pending_full_con:
            # 热加载会复制旧版 __dict__。旧“未满超时交棒”的 pending 不能
            # 绕过新硬条件补发数字键；真正已切出的事实也不能强行切回。
            if self._reconcile_visible_actor():
                if target.is_current_char:
                    begin_round = getattr(target, 'begin_round', None)
                    if callable(begin_round):
                        begin_round()
                return False
            if self._hud_active():
                self._pending_target = None
                self._pending_source_con = 0.0
                self._intro_guard_until = 0.0
                self.logger.info('守岸人：撤销旧版未满协奏交棒凭据，重新积满，不补切人键')
            elif time.time() >= self._pending_switch_until + self.LIBERATION_START_CONFIRM:
                self._cancel_switch('旧交棒票据到期且 HUD 未恢复')
            return False
        start, last_send, hits = time.time(), -1.0, 0
        other_hits, other_index = 0, None
        if self._pending_target is None:
            if not self._hud_active():
                return False
            con = self._observe_con() if source_con is None else source_con
            if con is None:
                return False
            full = con == 1
            if not full:
                return False
            # 只复用本轮主循环刚完成的确认，不能泛用先前 R／补能遗留计数。
            # R 返回已清零计数；没有显式凭据的入口仍须从零采集三帧。
            if (not (full_con_confirmed and source_con == 1
                     and self._con_hits >= self.CON_CONFIRM_FRAMES)
                    and not self._confirm_full_con()):
                return False
            if not self._settle_full_con_before_switch():
                return False
            con = self.current_con
            timing = (f'，距 R 后 HUD 恢复 {time.time() - self._liberation_ready_at:.3f}s'
                      if self._liberation_ready_at is not None else '')
            self.logger.info(f'守岸人：交棒前连续确认满协奏，R已确认={self._visit_liberated}{timing}')
            self._capture_con_ring_snapshot()
            self._pending_target = target
            self._pending_full_con = True
            self._pending_source_con = con
            self._pending_wait_con_logged = False
            self._pending_switch_until = time.time() + self.INTRO_TIMEOUT
            self._intro_guard_until = self._pending_switch_until + self.LIBERATION_START_CONFIRM
            # 所有会读取状态、准备记账或建立保护的动作均已完成。
            # 最后一次 Q 与下面的数字切人键之间，不得添加可执行观察／等待。
            try:
                if not self._ensure_echo():
                    # 尚未发数字键；下次按实时协奏重新准备，保留 Q 尝试次数。
                    self._pending_target = None
                    return False
            except BaseException:
                # 暂停／异常发生在 Q 阶段，不得恢复成已经发过数字键的交接。
                self._pending_target = None
                raise
            self.task.send_key(target.index + 1)
            last_send = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            self.task.next_frame()
            if not any(char is self for char in self.task.chars):
                return False
            if time.time() < self._pending_switch_until:
                self.check_combat()
            in_team, index, _ = self.task.in_team()
            if in_team and index == target.index:
                other_hits, other_index = 0, None
                hits += 1
                if hits >= self.CD_CONFIRM_FRAMES:
                    # switch_out 会清驻场字段，先取出本笔快照中的满协奏
                    # 条件；确认目标后才统一更新双方状态并开启锁冥新轮次。
                    full = self._pending_full_con
                    con_snapshot = self._con_ring_snapshot
                    self.current_con = self._pending_source_con
                    self.switch_out(con_full=full)
                    for char in self.task.chars:
                        if char is not None:
                            char.is_current_char = char is target
                    target.has_intro = full
                    target.has_sub_dps_intro = False
                    target.last_switch_in_time = time.time()
                    if full:
                        self.last_outro_time = time.time()
                        self.add_freeze_duration(time.time(), target.intro_motion_freeze_duration, -100)
                    begin_round = getattr(target, 'begin_round', None)
                    if callable(begin_round):
                        begin_round()
                    self.task.in_liberation = False
                    self._save_con_ring_snapshot(con_snapshot)
                    return True
            else:
                hits = 0
                if in_team and index != self.index:
                    # 第三槽位必须连续稳定，才认定本笔交锁已被真实外换取代。
                    # 单帧误识别不能丢掉源协奏快照／pending，亦不能抢发数字键。
                    other_hits = other_hits + 1 if index == other_index else 1
                    other_index = index
                    if other_hits >= self.HUD_CONFIRM_FRAMES:
                        for char in self.task.chars:
                            if char is not None:
                                char.is_current_char = char.index == index
                        self._clear_visit()
                        self.logger.warning('切人期间连续确认其他角色，按实际槽位交还调度')
                        return False
                else:
                    # 源槽位重新出现或 HUD 隐藏均打断连续第三槽位证据；
                    # 目标槽位的分支也单独清零，不能跨不相邻画面拼接确认。
                    other_hits, other_index = 0, None
                if (in_team and index == self.index and time.time() < self._pending_switch_until
                        and time.time() - last_send >= self.SWITCH_RETRY_INTERVAL):
                    # 只在源角色真实可见时重读源协奏。第一次切换可能已经消耗
                    # 协奏但入场动画尚未送达，此时只观察，不拿旧满值补发数字键；
                    # 目标回执若实际出现仍沿用原有效票据确认，不伪造另一笔延奏。
                    retry_con = self._observe_con(advance_frame=False)
                    if (retry_con == 1 and self._hud_active()
                            and time.time() < self._pending_switch_until):
                        self.task.send_key(target.index + 1)
                        last_send = time.time()
                    elif not getattr(self, '_pending_wait_con_logged', False):
                        self._pending_wait_con_logged = True
                        self.logger.info(f'守岸人：切人待确认时源协奏={retry_con}，暂停补切键，只等原回执')
            if time.time() >= self._pending_switch_until + self.LIBERATION_START_CONFIRM:
                self._cancel_switch('切锁绝对送达期限已到，未取得连续目标回执')
                return False
            self.sleep(self.POLL_INTERVAL)
        self.logger.warning('守岸人切锁冥未确认成功，在同一绝对送达期限内继续核实')
        return False

    def _cancel_switch(self, reason):
        """解除切人失败票据，不伪造切出、变奏或满协奏；下次重读实际角色。"""
        self._pending_target = None
        self._pending_switch_until = 0.0
        self._pending_full_con = False
        self._pending_source_con = 0.0
        self._con_hits = 0
        self._full_switch_ready_at = None
        self._pending_wait_con_logged = False
        self._intro_guard_until = 0.0
        self._action_recovery_until = time.time() + self.ACTION_RECOVERY_GUARD
        self.logger.warning(f'守岸人：{reason}；解除旧切人等待，恢复实际角色与协奏判断')

    def do_perform(self):
        """按可恢复工作片推进驻场；超时可结束争取 R，但绝不能未满交场。

        首先恢复切人和 R，然后做一次入场准备。补能起点、首次满协奏
        起点与补协奏起点独立保留；只把本次工作片起点重新计时，避免
        每次调度恢复都给同一驻场无限补能预算。
        """
        # 发过切人键后，先核实上一笔交接；不在旧角色标记上重新跑动作。
        if self._pending_target is not None:
            self._switch_to_suoming()
            return
        if self._reconcile_visible_actor():
            return
        if self._liberation_pending is not None and not self._cast_liberation():
            return
        if not self._entry_done and not self._prepare_entry():
            return
        if self._energy_started is None:
            self._energy_started = time.time()
        start = time.time()
        # 交棒凭据只累计本主循环的连续帧，不沿用入场／上一时间片的读数。
        self._con_hits = 0
        while self.time_elapsed_accounting_for_freeze(start) < self.WORK_SLICE:
            con = self._observe_con()
            if con is None:
                if self._reconcile_visible_actor():
                    return
                self.sleep(self.POLL_INTERVAL)
                continue
            if con == 1 and self._con_hits < self.CON_CONFIRM_FRAMES:
                self.sleep(self.POLL_INTERVAL)
                continue
            full = con == 1
            if (self._con_rescue_since is None
                    and (self._visit_liberated or self.time_elapsed_accounting_for_freeze(
                        self._energy_started) >= self.ENERGY_BUILD_TIMEOUT)):
                self._con_rescue_since = time.time()
            # full 是已累计连续帧后的本帧满值。首次达满的时间锚只写一次，
            # 后续识别抖动不擦除它，从而守住 R 前的补能宽限。
            if full and self._full_con_since is None:
                self._full_con_since = time.time()
            # R 前的满协奏补能截止点不被 99% 重置；R 成功后改走独立的补协奏窗口。
            budget_at = time.time()
            grace_left = self.WORK_SLICE
            if self._full_con_since is not None and not self._visit_liberated:
                grace_left = self.FULL_CON_ENERGY_GRACE - self.time_elapsed_accounting_for_freeze(
                    self._full_con_since)
            rescue_left = (self.CONCERTO_RESCUE_TIMEOUT - self.time_elapsed_accounting_for_freeze(
                self._con_rescue_since)) if self._con_rescue_since is not None else None
            startup_budget = grace_left
            if not full:
                energy_left = self.ENERGY_BUILD_TIMEOUT - self.time_elapsed_accounting_for_freeze(
                    self._energy_started)
                startup_budget = min(startup_budget, rescue_left if rescue_left is not None else energy_left)
            startup_deadline = budget_at + max(0, startup_budget)
            # R 只有在外层仍有剩余预算时才允许启动；把同一绝对截止点传入
            # 内层重按循环，避免内层识别耗时另开一段完整 R 启动等待。
            # 关闭 R 时不进入会立即失败后 continue 的优先分支；仍按原有
            # 预算补 A／E 和回路，避免只读图空转到补能／补协奏期限结束。
            if (self.task.use_liberation and not self._visit_liberated
                    and (con >= self.LIBERATION_MIN_CON or rescue_left is not None)
                    and time.time() >= self._next_liberation
                    and grace_left > 0 and (full or rescue_left is None or rescue_left > 0)):
                ready_started = time.time()
                ready = self.liberation_available()
                ready_elapsed = time.time() - ready_started
                if ready:
                    self.logger.info(f'守岸人：R 资格已确认，协奏={con:.0%}，可用性识别耗时 {ready_elapsed:.3f}s')
                    self._cast_liberation(startup_deadline=startup_deadline, ready_checked=True)
                    self._con_hits = 0
                    self._next_liberation = time.time() + self.SKILL_RETRY_INTERVAL
                    if self._liberation_pending is not None:
                        return
                    continue
                if not getattr(self, '_r_wait_logged', False):
                    self._r_wait_logged = True
                    self.logger.info(f'守岸人：已到 R 协奏条件但 R 尚不可用，协奏={con:.0%}，'
                                     f'可用性识别耗时 {ready_elapsed:.3f}s，继续补能')
            if full and not self._visit_liberated:
                # 可用性 OCR 也消耗满协奏后的三秒宽限，不能用读图前的余量补 A。
                grace_left = min(grace_left, startup_deadline - time.time())
            if full and (self._visit_liberated or grace_left <= 0 or not self.task.use_liberation):
                # 可以放弃没能开出的 R，但不允许放弃满协奏。
                self._switch_to_suoming(source_con=con, full_con_confirmed=True)
                return
            if not full and rescue_left is not None and rescue_left <= 0:
                if not self._strict_con_wait_logged:
                    self._strict_con_wait_logged = True
                    self.logger.info('守岸人：补协奏窗口已过，按严格满协奏规则继续留场，不切人')
            # 旧补能／补协奏期限只限制 R 争取时间。协奏未满时仍给本工作片
            # 剩余输入预算，不能把过期的负预算变成空转或未满强制切人。
            budget = self.WORK_SLICE - self.time_elapsed_accounting_for_freeze(start)
            if full:
                budget = min(budget, max(0.0, grace_left))
            self._build_energy(budget, con)
            # 补能可能发出 E／重击／A；交棒前重新累计动作结束后的连续帧。
            self._con_hits = 0
        self.logger.debug('守岸人本时间片结束，协奏未满或步骤未确认，继续留场')
