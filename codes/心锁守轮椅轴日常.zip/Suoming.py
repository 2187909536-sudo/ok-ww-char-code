"""心／锁冥／守岸人队伍中的锁冥动作与三人交棒协调。

此文件沿用原角色的识别和输入接口，另行管理本队的一轮顺序。技能发键、
冷却确认、动画恢复和切人送达是不同阶段：只有相应证据齐全才推进阶段。
协奏读数只属于当前可见角色；已发出的交棒保留源角色快照，恢复时不能
拿入场角色或已消耗后的读数改写这笔交棒。所有交接完成准备后 Q 直接切人。
"""

import math
import time

from src.char.Suoming import Suoming as NativeSuoming
from src.char.BaseChar import SwitchPriority


class _BreakReady(Exception):
    """先退出当前动作并释放持键，再由角色入口执行处决。"""


class Suoming(NativeSuoming):
    """以 R／同奏为优先条件，并持有心与守岸人之间的交棒状态。

    守岸人确认交场后开启一轮：锁冥首次交心、心 R1 交回锁冥、锁冥再次
    交心，最后由心完成后半段交守岸人。首次允许满协奏普通延奏兜底；
    再次普通交心前必须已获得锁冥 R 和有效同奏交棒证据。送达时机不明则进入
    hsin_unison_recovery，回锁重建条件，不直接承认心已得到强化入场。
    """

    # 代码修订只用于现有日志识别；下列时长均以秒为单位。
    CODE_REVISION = '2026-10-25-break-guard-21'
    # 楽山心锁守 2.0.0 的 A_TAP / SO_A_EVERY：60ms 持键、200ms 整周期。
    # 10ms 的短按可能被动作收招吞掉；增加有效持键，不额外添加动作后等待。
    ATTACK_HOLD = 0.06
    ATTACK_INTERVAL = 0.20
    POLL = 0.0
    # 技能／槽位采用连续帧证据，满协奏采用更长确认，避免单帧误识别推进。
    CONFIRM_FRAMES = 2
    CON_FRAMES = 3
    # 普通满协奏交棒前，最多四帧寻找连续两帧相同的 R 可用性；
    # 一帧暗色／CD 读数不能放行交棒，持续不稳定则让出本次工作片继续观察。
    R_OUTRO_MAX_FRAMES = 2 * CONFIRM_FRAMES
    # 单次调度的工作片；实际循环会扣除已记录的演出冻结时间。
    WORK_SLICE = 8.00
    # E 发键间隔、普通 E 消耗确认窗口；FOLLOWUP_HOLD 是一次观察预算。
    # 原生 Suoming.hold_forte_resonance 每轮持 E 2s，提示消耗后继续持 E
    # 3s 才等恢复。两段采用独立且不续期的锚点，不能由 E 泛白提前结束。
    E_RETRY = 0.10
    E_TAP = 0.05  # 参考轴 SO_KX_E_TAP；后台 E 首键也保留足够的按下时间。
    E_CONFIRM_TIMEOUT = 0.90
    FOLLOWUP_HOLD = 2.00
    ACTION_WAIT = 3.00
    FORTE_INPUT_HOLD = 2.00
    FORTE_INPUT_LIMIT = NativeSuoming.RESONANCE_HOLD_TIMEOUT
    FORTE_TAIL_HOLD = 3.00
    # 启动尚未消耗提示、并且 E 已恢复可输入时，按原生方式松 .1s 再重按一次。
    # 已确认进入派生后不走启动重试，完整持键／收尾保护保持独占。
    FORTE_START_RETRIES = 1
    FORTE_REPRESS_RELEASE = .10
    FORTE_RELEASE_SETTLE = .20
    FORTE_RESTORE_TIMEOUT = 3.00
    ACTION_RECOVERY_GUARD = .60
    # R 启动、无藏 HUD 情况下的最短等待、单次动画观察上限是三个不同预算。
    R_START_TIMEOUT = 1.60
    R_NO_ANIMATION_GRACE = 0.40
    R_ANIMATION_TIMEOUT = 6.00
    # 只在本次 R 消耗与 HUD 恢复连续确认后，给交心前的 Q 留 200ms 收招。
    # 这不是声骸验证或动画冻结；刻心念后的普通满协奏交心不经过此等待。
    R_HANDOFF_RECOVERY = 0.20
    # 未确认 R 只能有限补按；第二次交心缺少同奏时退避后允许新一批尝试。
    R_RETRY = 0.10
    R_MAX_FAILURES = 3
    R_FAILURE_RECOVERY = 1.00
    # 同奏窗口从确认关联的发键时刻起算，再由动画冻结修正剩余有效时间。
    UNISON_DURATION = 5.00
    # 交棒前至少预留 Q 与数字键的按键时长；重试只重发数字键。
    Q_TAP = 0.05
    # 无常凶鹭轻云轴采用有限双短按。本轴保留 50ms 持键，两个 Q 之间
    # 只松键 10ms，总动作 110ms；末次 Q 后不加留场或效果识别。
    Q_RETRY_GAP = 0.01
    SWITCH_TAP = 0.02
    UNISON_SWITCH_MARGIN = Q_TAP + SWITCH_TAP
    SUOMING_UNISON_SWITCH_MARGIN = 2 * Q_TAP + Q_RETRY_GAP + SWITCH_TAP
    SWITCH_RETRY = 0.05
    SWITCH_TIMEOUT = 2.50
    # 变奏／交棒等待期间暂缓框架脱战误判，并给延迟的槽位回执留时间。
    INTRO_GUARD = 6.00
    # 借鉴楽山心锁守 break_prompt / break_press：只认怪物身上的实际 F 提示。
    # 顶部偏谐条满可能还须攻击命中才生成提示，不能拿它抢占下一次普攻。
    # 处决只发 F，不调用会夹带普攻的 task.f_break；失败后正常动作自行续打。
    BREAK_POLL = .15
    BREAK_CENTER_THRESHOLD = .90
    BREAK_TAP = .05
    BREAK_RETRY = .30
    BREAK_MAX_PRESSES = 5
    BREAK_GONE_FRAMES = 3
    BREAK_RECOVERY_HSIN = 1.40
    BREAK_RECOVERY_OTHER = 1.60
    BREAK_TIMEOUT = 3.0
    # 尝试后的门闩由全队共享，普通切人／新工作片不能重新开始同一个 F。
    # 至少让出 3s 给实际动作，且自身 HUD 可读时提示连续消失 .30s 才重新开放。
    BREAK_REARM_DELAY = 3.0
    BREAK_CLEAR_TIME = .30

    def __init__(self, *args, **kwargs):
        """分别初始化跨驻场轮次状态与本次驻场状态，再输出既有修订标识。"""
        super().__init__(*args, **kwargs)
        # 字典让代码重新导入时的浅复制共享同一笔处决状态；旧调用栈退出时
        # finally 也能清除新实例继承的 running，避免永久停用处决。
        self._break_state = {'running': False, 'next_probe': 0.0}
        self._reset_round()
        self._clear_visit()
        self.logger.info(f'心锁守代码修订：Suoming {self.CODE_REVISION}')

    def _reset_round(self):
        """开启整轮顺序；这些计数不会随着普通 switch_out 被清除。"""
        # phase 决定调度与交棒资格；计数记录延奏总数、确认 R 和同奏延奏。
        self.round_phase = 'suoming_first'
        self.outro_count = 0
        self.round_r_casts = 0
        self.round_unison_outros = 0
        self.round_skipped_to_late = False

    def _clear_visit(self):
        """只清除本次上场的动作、输入恢复和等待凭据，保留整轮进度。"""
        self._release_forte_key()
        # 入场标记与两类保护截止点：本对象交棒、外部协调器交入本角色。
        self._entry_done = False
        self._pending = None
        self._guard_until = 0.0
        self._team_entry_guard_until = 0.0
        self._action_recovery_until = 0.0
        # 技能重试节流与特殊 E 派生进度，均不能跨真实离场沿用。
        self._next_e = self._next_r = 0.0
        self._followup = False
        self._forte_pending = None
        self._followup_tries = 0
        self._lock_hint_since = None
        # R 的未决证据与已确认同奏截止点分别保存，候选动画不能充当成功。
        self._r_pending = None
        self._r_failures = 0
        self._r_observation = None
        self._unison_until = 0.0
        self.check_f_on_switch = False

    def begin_round(self):
        """由守岸人确认交入锁冥时调用，同时重置整轮与驻场局部状态。"""
        self._reset_round()
        self._clear_visit()

    def reset_state(self):
        """随框架重置清理原生角色状态，并恢复本队初始轮次。"""
        super().reset_state()
        self.begin_round()
        self._reset_break_gate()

    def _reset_break_gate(self):
        """框架重置或真正脱战才清处决门闩；一轮开始、普通切人不能清。"""
        state = self._break_context()
        if not state['running']:
            # 原地清理保持热重载的字典共享，不替换旧 finally 所持有的对象。
            state.clear()
            state.update(running=False, next_probe=0.0)

    def on_combat_end(self, chars):
        """下一场战斗可重新尝试 F，不继承上一场尚未消失的敌人提示。"""
        super().on_combat_end(chars)
        self._reset_break_gate()

    def switch_out(self, con_full=False):
        """让原生逻辑处理离场资源，再清本次驻场，轮次计数继续保留。"""
        super().switch_out(con_full=con_full)
        self._clear_visit()

    def is_dps_config(self):
        """固定采用本队辅助路线，防止原生输出模式自行使用同奏。"""
        # 此队固定为辅助同奏路线，不能让全局 DPS 选项消费掉交棒用的同奏。
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """心后半与守岸人阶段拒绝通用调度抢回锁冥，其余沿用原生优先级。"""
        if self.round_phase in ('hsin_late', 'keeper'):
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _opening_keeper(self):
        """查找带本队首发协调接口的守岸人，缺少接口时允许回落原生流程。"""
        return next((c for c in self.task.chars if c is not None
                     and c.char_name == 'char_shorekeeper'
                     and callable(getattr(c, 'ensure_opening', None))), None)

    def perform(self):
        """先满足守岸人首发保证；尚未确认交场时不执行锁冥动作。"""
        try:
            if self._forte_pending is not None:
                # 上一工作片仍持有 E 时，首发协调也不能借机另发动作键。
                return super().perform()
            keeper = self._opening_keeper()
            if keeper is not None and not keeper.ensure_opening(self):
                return
            return super().perform()
        except _BreakReady:
            return self.perform_ready_break(self)

    def check_combat(self):
        """先检查可执行处决，避免进入长索敌；刻心念独占时 probe 永远拒绝。"""
        if self.break_ready(self):
            raise _BreakReady()
        return super().check_combat()

    def _break_prompt_visible(self):
        """只认当前帧怪物身上的 F，排除拾取；条满和 can_break 缓存不算。"""
        return bool(self.task.find_one('f_break', box=self.task.box_of_screen(
                    .2, .2, .75, .8, hcenter=True, vcenter=True), target_height=720,
                    threshold=self.BREAK_CENTER_THRESHOLD)
                    and not self.task.is_pick_f())

    def _break_context(self):
        """兼容旧版本热重载时缺少的新字段，并保留处决过程中的共享状态。"""
        state = getattr(self, '_break_state', None)
        if state is None:
            state = {'running': False, 'next_probe': 0.0}
            self._break_state = state
        # 兼容 v20 浅复制而来的旧字典；不得因缺字段重置已存在的共享状态。
        state.setdefault('blocked', False)
        state.setdefault('clear_since', None)
        state.setdefault('rearm_after', 0.0)
        return state

    def break_ready(self, source, *, fresh=False):
        """全队共用处决资格；只更新观察门闩，不在持鼠标的动作栈里发送 F。

        刻心念／衔接 pending 是最高级独占门闩，任何角色入口均不能绕过。
        已发切人、R启动／演出也先完成原子交接；普通攻击和重击检查点可立即让出。
        尝试过的同一个提示必须先稳定消失，再允许后续新提示抢占。
        fresh 只跳过采样节流，绝不能绕过这个跨调度、跨切人的失败保护。
        """
        state = self._break_context()
        if (self._forte_pending is not None or state['running']
                or self._pending is not None or not getattr(self.task, '_in_combat', False)
                or self.task.in_liberation):
            state['clear_since'] = None
            return False
        current = self._current_team_char(source)
        if current is not source or not source.is_current_char or not self._active(source):
            state['clear_since'] = None  # 丢 HUD／换槽不能充当提示已消失的证据。
            return False
        if (getattr(source, '_r_pending', None) is not None
                or getattr(source, '_liberation_pending', None) is not None
                or getattr(source, '_pending_target', None) is not None):
            state['clear_since'] = None
            return False
        now = time.time()
        if not fresh and now < state['next_probe']:
            return False
        if now - state.get('last_probe', now) > 3 * self.BREAK_POLL:
            state['clear_since'] = None  # 长动作期间没有采样，不能累计“连续消失”。
        state['last_probe'] = now
        state['next_probe'] = now + self.BREAK_POLL
        prompt = self._break_prompt_visible()
        if state['blocked']:
            if prompt:
                state['clear_since'] = None
            elif state['clear_since'] is None:
                state['clear_since'] = now
            elif (now >= state['rearm_after']
                  and now - state['clear_since'] >= self.BREAK_CLEAR_TIME):
                state['blocked'] = False
                state['clear_since'] = None
            return False
        return prompt

    def perform_ready_break(self, source):
        """动作栈已退出、finally 已松键后，在单次绝对三秒预算内尝试处决。

        全程不夹带普攻。临时豁免只覆盖本次有限处决观察，finally 恢复原状态；
        暂停／停止仍由 next_frame 与任务 sleep 检查。提示连续消失后停止补 F，
        再等本角色 HUD 恢复；不能将“HUD一直在”当成执行成功。无论结果如何，
        本次已发键的提示均锁定，后续调度继续 A／E／R／交棒，不重开三秒预算。
        """
        if not self.break_ready(source, fresh=True):
            return False
        previous_skip = getattr(self.task, 'skip_combat_check', False)
        state = self._break_context()
        state['running'] = True
        self.task.skip_combat_check = True
        start, presses, last_send = time.time(), 0, -1.0
        hidden_at, restored, gone_hits = None, 0, 0
        prompt_gone = False
        recovery = (self.BREAK_RECOVERY_HSIN if source.char_name == 'char_hsin'
                    else self.BREAK_RECOVERY_OTHER)
        try:
            while time.time() - start < self.BREAK_TIMEOUT:
                if self._forte_pending is not None or self._current_team_char(source) is not source:
                    break
                visible, index, _ = self.task.in_team()
                if visible and index != source.index:
                    break
                now = time.time()
                if not visible:
                    if not presses:
                        break  # 未发送 F 就丢 HUD，交回原动作恢复，不在此空等三秒。
                    # 首个 F 尚未发出时的 HUD 波动不能算作处决冻结。
                    if presses:
                        hidden_at = now if hidden_at is None else hidden_at
                    gone_hits = 0  # HUD 不在不能证明怪物身上的 F 已消耗。
                    restored = 0
                else:
                    if hidden_at is not None:
                        self.add_freeze_duration(hidden_at, now - hidden_at)
                        hidden_at = None
                    prompt = self._break_prompt_visible()
                    if not prompt and not presses:
                        break  # 提示已消失且从未发键，本次无须执行或等待处决。
                    gone_hits = gone_hits + 1 if presses and not prompt else 0
                    prompt_gone = gone_hits >= self.BREAK_GONE_FRAMES
                    if (prompt and presses < self.BREAK_MAX_PRESSES
                            and now - last_send >= self.BREAK_RETRY):
                        self.task.send_key('f', down_time=self.BREAK_TAP, interval=0)
                        presses += 1
                        last_send = time.time()
                        self.task.can_break = False
                    if prompt_gone and now - last_send >= recovery:
                        restored += 1
                        if restored >= self.CONFIRM_FRAMES:
                            break
                    else:
                        restored = 0
                self.task.sleep(.02)
                self.task.next_frame()
        finally:
            self.task.skip_combat_check = previous_skip
            state['running'] = False
            state['next_probe'] = time.time() + self.BREAK_POLL
            if presses:
                state['blocked'] = True
                state['clear_since'] = None
                state['rearm_after'] = time.time() + self.BREAK_REARM_DELAY
            self.task.can_break = False
        if presses:
            observed = prompt_gone and restored >= self.CONFIRM_FRAMES
            self.logger.info(f'心锁守：{source.name} 处决尝试 {time.time() - start:.2f}s，F 输入 {presses} 次，'
                             f'实际提示消失并恢复={observed}；'
                             '本提示不重复抢占，继续下一动作（提示稳定消失后才重新开放）')
        return presses > 0

    def switch_other_char(self, allow_auto_combat=False):
        """自动战斗的战前／战后切奶交给同一首发协调器，但不消耗下一轮保证。"""
        if self._forte_pending is not None:
            return False
        keeper = self._opening_keeper()
        if keeper is not None and allow_auto_combat:
            return keeper.ensure_opening(self, commit=False, check_combat=False)
        return super().switch_other_char(allow_auto_combat=allow_auto_combat)

    def skip_combat_check(self):
        """交棒、首发或已发 E／刻心念期间，暂缓可能被动画干扰的脱战检查。"""
        keeper = self._opening_keeper()
        return (self._forte_pending is not None
                or time.time() < max(self._guard_until, self._team_entry_guard_until,
                                     getattr(self, '_action_recovery_until', 0.0))
                or bool(keeper is not None and keeper.opening_guard_active()))

    def _active(self, source=None):
        """以可见队伍 HUD 的槽位核对角色，不能只依赖框架的当前角色标记。"""
        visible, index, _ = self.task.in_team()
        return bool(visible and index == (source or self).index)

    def _frame(self):
        """推进画面并执行现有战斗检查，返回这帧是否仍能确认锁冥在场。"""
        self.task.next_frame()
        self.check_combat()
        return self._active()

    def _read_con(self):
        """读取锁冥自己的归一化协奏；无效／越界 OCR 返回未知，不补成零或满。"""
        if not self._active():
            return None
        try:
            con = float(self.task.get_current_con())
        except (ValueError, TypeError):
            return None
        if not math.isfinite(con) or not 0 <= con <= 1:
            return None
        self.current_con = con
        return con

    def _full_con(self):
        """要求连续 CON_FRAMES 帧均为锁冥满协奏，中途丢 HUD 即撤销确认。"""
        for _ in range(self.CON_FRAMES):
            if not self._frame() or self._read_con() != 1:
                return False
            self.sleep(self.POLL)
        return True

    def _r_ready(self, before_outro=False):
        """以连续可用帧决定是否尝试 R，交棒前还须连续确认不可用。

        普通巡检遇到否即可回到 E／普攻；它没有批准切人的效力。满协奏
        最后复核则在有限帧内寻找稳定结果，混合帧／丢 HUD 都不能作为
        普通交棒依据。短暂重试退避也不是“R 不可用”，不能绕过剩余尝试。
        """
        observation = {'result': 'unknown', 'samples': []}
        self._r_observation = observation
        if self._forte_pending is not None:
            # 灰 R 上的白色键位字也可能被通用 available 判亮。已发出的
            # 无舍念／刻心念必须先收尾，期间连 R 读屏探测都不执行。
            observation['result'] = 'protected_forte'
            return False
        if not self.task.use_liberation:
            observation['result'] = 'disabled'
            return False
        if time.time() < self._next_r:
            observation['result'] = 'backoff'
            return False
        ready_hits, unavailable_hits = 0, 0
        frames = self.R_OUTRO_MAX_FRAMES if before_outro else self.CONFIRM_FRAMES
        for _ in range(frames):
            if not self._frame():
                observation['result'] = 'actor_unknown'
                return False
            highlighted = bool(self.task.available(
                'liberation', check_color=True, check_cd=False))
            if not highlighted and not before_outro:
                # 常规打能量路径保留原生 available 的颜色短路，暗图标不额外
                # 触发整排 CD OCR；只有最后交棒复核必须采齐暗色帧的 CD 诊断。
                self._r_failures = 0
                observation['result'] = 'unavailable'
                return False
            try:
                cd = float(self.task.get_cd('liberation', self.index))
            except (TypeError, ValueError):
                cd = float('nan')
            # 与原生 BaseCombatTask.has_cd 的 >0.2s 判据一致。原生 CD OCR
            # 未识别数字时也返回 0，因此“暗且无 CD”不能进一步断言缺能量：
            # 它还可能是形态未解锁／入场锁定／识别缺失。日志只保存原始观测。
            ready = highlighted and cd <= 0.2 if math.isfinite(cd) else None
            observation['samples'].append((highlighted, cd))
            ready_hits = ready_hits + 1 if ready is True else 0
            unavailable_hits = unavailable_hits + 1 if ready is False else 0
            if ready_hits >= self.CONFIRM_FRAMES:
                if self._r_failures >= self.R_MAX_FAILURES and self._requires_r_before_outro():
                    # 第二次不能走双普通延奏兜底；经过退避后重新允许有限重试。
                    self._r_failures = 0
                allowed = self._r_failures < self.R_MAX_FAILURES
                observation['result'] = 'ready' if allowed else 'exhausted'
                return allowed
            if ((not before_outro and ready is False)
                    or unavailable_hits >= self.CONFIRM_FRAMES):
                self._r_failures = 0
                observation['result'] = 'unavailable'
                return False
            self.sleep(self.POLL)
        observation['result'] = 'unstable'
        return False

    def _requires_r_before_outro(self):
        """首次交心以后，整轮须同时有确认 R 与有效同奏延奏才能普通交棒。"""
        return self.outro_count >= 1 and not (self.round_r_casts > 0 and self.round_unison_outros > 0)

    def _e_highlighted(self):
        """读取通用 E 白色像素线索；它不能单独证明刻心念终结已结束。"""
        return self._active() and bool(self.task.available(
            'resonance', check_color=True, check_cd=False))

    def _locked(self):
        """用 E 无冷却却无亮色提示作为输入锁定线索，不把它当技能成功证据。"""
        # E 没有 CD 却不能输入：终结动作或受击硬直。禁止凭满协奏抢切。
        return self._active() and not self._e_highlighted() and not self.task.has_cd('resonance')

    def _attack(self):
        """在自己 HUD 有效且战斗检查通过时发送一次按既定周期节流的普攻。"""
        if self._forte_pending is not None:
            return
        if not self._active():
            return
        self.check_combat()
        if (self._forte_pending is not None or not self._active()
                or self._current_team_char(self) is not self):
            return
        self.task.click(down_time=self.ATTACK_HOLD)
        self.sleep(self.ATTACK_INTERVAL - self.ATTACK_HOLD)

    def _prepare_entry(self):
        """确认本角色已在场即可结束入场准备，不再添加固定普攻垫场。"""
        if not self._active():
            return False
        self._entry_done = True
        self._guard_until = 0.0
        self._team_entry_guard_until = 0.0
        return self._active()

    def _confirm_r(self, pending):
        """对同一未决 R 只记一次确认，并保存用于立即交棒的协奏估计。

        调用者须先取得发键后的连续冷却证据。协奏加成是本次确认 R 的
        既定收益估计，不是新的 OCR；交棒快路径依赖它避免再花时间读屏。
        """
        if pending['confirmed']:
            return
        pending['confirmed'] = True
        self.record_liberation_use()
        self.round_r_casts += 1
        accepted = pending['accepted'] if pending['accepted'] is not None else pending['last_send']
        self._unison_until = accepted + self.UNISON_DURATION
        self.current_con = min(1.0, self.current_con + 0.20)

    def _cast_r(self, ready_checked=False):
        """建立或恢复一笔 R：有限补按、确认消耗，再等待 HUD 恢复。

        False 既可能表示本次明确未成功，也可能表示动画观察时间片结束；
        后者仍保留 _r_pending，下一次必须先恢复该步骤，不能插入 E／普攻。
        ready_checked 仅省略调用者刚完成的可用性检查，不跳过成功确认。
        """
        if self._forte_pending is not None:
            return False
        pending = self._r_pending
        if pending is None:
            if not ready_checked and not self._r_ready():
                return False
            self._read_con()
            # start／first_send 控制尝试期限；last_send 是最近输入；accepted
            # 关联藏 HUD 的那次输入。hidden 收集动画区间，confirmed 独立
            # 记录 CD 证据，candidate_until 只限制不确定动画的保护期限。
            pending = {'start': time.time(), 'last_send': -1.0,
                       'first_send': None, 'accepted': None, 'hidden': [], 'confirmed': False, 'gone': None,
                       'hud_back_at': None, 'candidate_until': None,
                       'gone_hits': 0, 'recorded_freeze': False}
            self._r_pending = pending
        anchor = pending['first_send'] if pending['first_send'] is not None else pending['start']
        pending.setdefault('observe_until', anchor + self.R_ANIMATION_TIMEOUT + self.ACTION_WAIT)
        start, cd_hits, back_hits = time.time(), 0, 0
        self.task.in_liberation = True
        try:
            # 本次调用只负责有限观察；pending 跨调用保存，finally 总会撤销
            # 框架演出标记，下一次由入口优先恢复，避免遗留全局状态。
            while time.time() - start < self.R_ANIMATION_TIMEOUT:
                sent_this_frame = False
                self.task.next_frame()
                frame_at = time.time()
                self.check_combat()
                visible, index, _ = self.task.in_team()
                active = bool(visible and index == self.index)
                if visible and index != self.index:
                    # 明确识别到其他槽位时交还真实角色，不能把切人误当 R 藏 HUD。
                    pending['gone_hits'] = 0
                    if self._reconcile_actor():
                        return False
                    if time.time() >= pending['observe_until']:
                        return self._abandon_r(pending, 'R 观察到期且当前槽位持续不稳定')
                    return False
                if not active:
                    if pending['last_send'] < 0:
                        self._r_pending = None
                        return False
                    if pending['gone'] is None or pending['hud_back_at'] is not None:
                        # 多次藏 HUD 可形成多个冻结区间；新输入接管候选时清除
                        # 旧输入的区间，避免把无关丢帧重复计入同奏延长。
                        if pending['accepted'] != pending['last_send']:
                            pending['accepted'] = pending['last_send']
                            pending['hidden'] = []
                        pending['gone'] = time.time()
                    pending['hud_back_at'] = None
                    pending['gone_hits'] += 1
                    # 藏 HUD 只是演出线索，还须确认 R 已消耗，不能单独记成功。
                    cd_hits = back_hits = 0
                else:
                    pending['gone_hits'] = 0
                    if pending['gone'] is not None and pending['hud_back_at'] is None:
                        pending['hud_back_at'] = time.time()
                        pending['hidden'].append((pending['gone'], pending['hud_back_at']))
                        # 未确认的演出只建立“可能仍有同奏”的保护上限，绝不记有效同奏。
                        if pending['candidate_until'] is None:
                            pending['candidate_until'] = min(pending['observe_until'],
                                pending['hud_back_at'] + self.UNISON_DURATION)
                    # 变灰也可能是受击硬直；只能以实际发键后的冷却确认 R 消耗。
                    cd = False if pending['confirmed'] else self.task.has_cd('liberation')
                    cd_hits = cd_hits + 1 if cd else 0
                    if (not pending['confirmed'] and pending['last_send'] >= 0
                            and cd_hits >= self.CONFIRM_FRAMES):
                        self._confirm_r(pending)
                    if (not pending['confirmed'] and not cd
                            and (pending['first_send'] is None or
                                 time.time() - pending['first_send'] < self.R_START_TIMEOUT)
                            and time.time() - pending['last_send'] >= self.R_RETRY
                            and self.task.available('liberation', check_color=True, check_cd=True)):
                        # available 的读图也消耗时间，真正发键前再核对截止点。
                        # 1.6s 只限制继续发送，不能同时取消最后一次输入的回执观察。
                        now = time.time()
                        send_start = (pending['first_send'] if pending['first_send'] is not None
                                      else pending['start'])
                        if now - send_start < self.R_START_TIMEOUT:
                            pending['last_send'] = now
                            if pending['first_send'] is None:
                                pending['first_send'] = now
                                pending['observe_until'] = now + self.R_ANIMATION_TIMEOUT + self.ACTION_WAIT
                            if pending['candidate_until'] is not None:
                                pending['candidate_until'] = max(pending['candidate_until'],
                                    now + self.UNISON_DURATION)
                            self.send_liberation_key(down_time=0.01)
                            sent_this_frame = True
                    if (pending['confirmed'] and (pending['gone'] is not None
                            or time.time() - pending['last_send'] >= self.R_NO_ANIMATION_GRACE)):
                        back_hits += 1
                        if back_hits >= self.CONFIRM_FRAMES:
                            # HUD 回来并不保证第一帧已能受理 Q。以本笔 R 首次
                            # 连续恢复确认时刻为锚点，只补一次短收招；放在 R
                            # 成功出口内，普通满协奏／刻心念交心不受影响。
                            if self._current_team_char(self) is not self:
                                return False
                            if 'q_ready_at' not in pending:
                                pending['q_ready_at'] = time.time() + self.R_HANDOFF_RECOVERY
                                self.logger.info('心锁守：锁冥 R 消耗与 HUD 恢复已确认，'
                                                 f'交心前 Q 留 {self.R_HANDOFF_RECOVERY:.2f}s 收招')
                            # pending 尚未清除，下一调度仍须先恢复 R。热重载
                            # 浅复制 __dict__ 时会承接同一个 pending 和绝对截止，
                            # 中断／重入只等余量，不能重新开始完整 200ms。
                            recovery_left = pending['q_ready_at'] - time.time()
                            if recovery_left > 0:
                                self.sleep(recovery_left, check_combat=False)
                            # sleep 期间可能重载角色；旧调用栈让出，禁止继续
                            # 清理新实例承接的 R 凭据或发起 Q／切人。
                            if self._current_team_char(self) is not self:
                                return False
                            # 消耗和恢复均确认后才一次性登记冻结，按有效流逝
                            # 时间重建同奏截止点，然后立即交回上层发起交棒。
                            # 上面的收招等待不登记为冻结，必须扣除真实同奏余量；
                            # 若剩余不足双 Q＋切人预算，上层原余量门槛拒绝发键。
                            if pending['gone'] is not None and not pending['recorded_freeze']:
                                for began, ended in pending['hidden']:
                                    self.add_freeze_duration(began, ended - began)
                                pending['recorded_freeze'] = True
                            accepted = pending['accepted'] if pending['accepted'] is not None else pending['last_send']
                            remaining = max(0.0, self.UNISON_DURATION
                                            - self.time_elapsed_accounting_for_freeze(accepted))
                            self._unison_until = time.time() + remaining
                            self._r_pending = None
                            self._followup = False
                            self.logger.info(f'心锁守：锁冥 R 已确认，立即交心；同奏余量 {remaining:.2f}s')
                            return True
                    else:
                        back_hits = 0
                attempt_start = pending['first_send'] if pending['first_send'] is not None else pending['start']
                if frame_at >= pending['observe_until']:
                    # 一笔 R 的总观察期限不能在每次恢复调用时重开。确认过的
                    # 消耗记账保留，但未证明送达的同奏不再拿来交棒。
                    return self._abandon_r(pending, '本笔 R 的总观察期限已到')
                # 本帧观察发生在发键之前，不能拿它否定本帧刚发出的 R。
                # 已发送的最后一次输入至少观察 0.4s；一帧 CD 线索也须保留
                # 到下一帧完成连续确认。尚未发过键的候选仍按原启动期限退出。
                # 观察下限必须看这帧取得的时刻：OCR 即使耗时跨过 0.4s，
                # 也不能把窗口内抓到的早期无 CD 画面当作窗口后的失败证据。
                receipt_observed = (pending['last_send'] < 0 or
                                    (frame_at - pending['last_send'] >= self.R_NO_ANIMATION_GRACE
                                     and cd_hits == 0))
                # 短暂藏 HUD 只给候选保护，恢复后保护过期且无 CD 才结束尝试。
                candidate_expired = (active and pending['candidate_until'] is not None
                                     and time.time() >= pending['candidate_until'] and cd_hits == 0)
                if (not pending['confirmed'] and time.time() - attempt_start >= self.R_START_TIMEOUT
                        and not sent_this_frame and receipt_observed
                        and (pending['gone'] is None or candidate_expired)):
                    self._r_pending = None
                    self._r_failures += 1
                    self._next_r = time.time() + self.R_RETRY
                    if self._r_failures >= self.R_MAX_FAILURES and self._requires_r_before_outro():
                        self._next_r = time.time() + self.R_FAILURE_RECOVERY
                    self.logger.warning('锁冥 R 未确认进入冷却，有限尝试已结束，恢复解锁／补能，不记同奏')
                    return False
                self.sleep(self.POLL)
        finally:
            self.task.in_liberation = False
        self.logger.warning('心锁守：锁冥 R 冷却／演出尚未确认，保留步骤，不进入 E 或普攻')
        return False

    def _abandon_r(self, pending, reason):
        """撤销无进展的 R 候选，保留已确认消耗，不补造有效同奏。"""
        if self._r_pending is not pending:
            return False
        self._r_pending = None
        self._unison_until = 0.0
        if not pending['confirmed']:
            self._r_failures += 1
        self._next_r = time.time() + self.R_FAILURE_RECOVERY
        self._action_recovery_until = time.time() + self.ACTION_RECOVERY_GUARD
        self.logger.warning(f'锁冥：{reason}，解除未决步骤并恢复实际补能；'
                            f'R消耗已确认={pending["confirmed"]}，不补造同奏')
        return False

    def _handoff_ready_unison(self):
        """有同奏即走最短交心路径；待确认交棒或实例已替换均要求让出本次调度。"""
        if self._current_team_char(self) is not self:
            # True 在这里表示本次应结束，不表示切人成功。旧调用栈必须
            # 立即让出，否则会在交棒方法拒绝旧实例后继续 A/E 或耗尽同奏。
            return True
        if self._forte_pending is not None:
            return False
        if self._unison_until - time.time() < self.SUOMING_UNISON_SWITCH_MARGIN:
            return False
        # R 前资源快照＋已确认的R收益已保存；此处不再读协奏OCR或检查E。
        switched = self._start_handoff(self, self._target_hsin(), self.current_con, self._unison_until)
        # _start_handoff 内的读图／日志也可能跨过重载，必须把此退出原因
        # 传回主循环；只返回 False 会让已失效实例继续执行后续动作。
        return (switched or self._pending is not None
                or self._current_team_char(self) is not self)

    def _save_e_for_forte(self):
        """有变奏／本轮进展证据时保留 E，先靠 A 攒出锁妄念／无舍念。

        参考楽山心锁守 2.0.0：念深里妄执未满就发普通 E 会进入冷却，
        拖延无舍念与刻心念。本队正常变奏和第二次入场都走强化 E；
        只有首次无变奏、也未确认 R 的异常开局保留原普通 E 补能入口。
        """
        return bool(self.has_intro or self.outro_count > 0 or self.round_r_casts > 0)

    def _use_e(self, special=False):
        """确认普通 E 或特殊 E 的实际消耗，并决定是否继续长按派生。

        普通 E 用 CD 证明消耗。特殊 E 在发键前建立跨工作片保护，随后
        立即衔接长按；不能等提示消失才保护，否则无舍念尚未清条时就会
        因确认超时返回主循环，被 R 探测或下一次 E 打断。
        """
        if self._forte_pending is not None:
            return self._continue_forte()
        if not self._active() or time.time() < self._next_e:
            return False
        if special:
            for _ in range(self.CONFIRM_FRAMES):
                if not self._frame() or not (self.forte_available() or self.is_e_forte_full()):
                    return False
                self.sleep(self.POLL)
        elif (self._save_e_for_forte()
              or not self.task.available('resonance', check_color=True, check_cd=True)):
            return False
        if special:
            # 锁妄念：E 清空妄执并进入念深，恢复后可正常 R。
            # 无舍念：先允许衔接刻心念，刻心念开始才清空妄执；因此不能
            # 把“E 没进 CD”或“强化提示还在”当成失败，再交回 R 分支。
            self._forte_pending = self._new_forte_pending()
            self._followup = True
            try:
                self.logger.info('锁冥：发送强化 E，先建立衔接／刻心念独占保护')
                self.send_resonance_key(down_time=self.E_TAP)
                self._next_e = time.time() + self.E_RETRY
                return self._continue_forte()
            except BaseException:
                self._release_forte_key()
                raise
        self.send_resonance_key(down_time=self.E_TAP)
        self._next_e = time.time() + self.E_RETRY
        start, cd_hits = time.time(), 0
        while time.time() - start < self.E_CONFIRM_TIMEOUT:
            if not self._frame():
                return False
            cd_hits = cd_hits + 1 if self.task.has_cd('resonance') else 0
            if cd_hits >= self.CONFIRM_FRAMES:
                self.record_resonance_use()
                # E 的实际消耗是新进展，不能沿用解锁前的 R 失败预算。
                self._r_failures = 0
                self._next_r = 0.0
                self._followup = False
                self._followup_tries = 0
                return True
            self.sleep(self.POLL)
        self.logger.warning('锁冥 E 未确认，重新看实时提示后补当前步骤')
        return False

    def _release_forte_key(self):
        """本对象持有 E 时才松键；用于动作完成、真实离场、重置或任务异常。"""
        pending = getattr(self, '_forte_pending', None)
        if pending is not None and pending['held']:
            self.task.send_key_up(pending['key'])
            pending['held'] = False
            pending['released_at'] = time.time()

    def _new_forte_pending(self):
        """保存一次 E 派生的输入、收尾和恢复锚点，跨调度片不重计时。"""
        return {'key': self.get_resonance_key(), 'held': False, 'created_at': time.time(),
                'hold_started': None, 'tail_started': None, 'hold_limit': None,
                'attempt_started': None, 'retries': 0, 'retry_hits': 0,
                'released_at': None, 'recovery_hits': 0,
                'input_logged': False,
                'gone_hits': 0, 'back_hits': 0,
                'locked_seen': False, 'hidden_seen': False, 'recorded': False}

    def _abandon_forte(self, pending, reason):
        """失败退出输入所有权，重新看实际技能；超时不是刻心念成功回执。"""
        if self._forte_pending is not pending:
            return False
        self._release_forte_key()
        self._forte_pending = None
        self._followup = False
        self._lock_hint_since = None
        self._next_e = time.time() + self.FORTE_RELEASE_SETTLE
        self._action_recovery_until = time.time() + self.ACTION_RECOVERY_GUARD
        self.logger.warning(f'锁冥：{reason}，已释放 E 并解除旧派生独占；'
                            '按当前提示补 A／重试，不记刻心念成功')
        return False

    def _continue_forte(self):
        """按原生两段持键保护派生，再单独确认当前 HUD 与输入线索恢复。

        至少持 E 2s，且提示消耗已确认后，开始一次完整 3s 的持键收尾。
        E 泛白在此期间只作日志线索，不能提前松键或放行 R／A／Q／切人。
        现有模板没有念劫结束分类器，因此这是原生动作预算＋恢复观测，
        不能称为终结形态已识别。原生 6s 输入观察＋3s 收尾也是持键上限；
        到持键上限先松 E，再有限确认恢复；仍不明则按失败退出旧步骤。
        未确认启动可有限重新按下，不能永远等待一个没有成功启动的演出结束。
        """
        pending = self._forte_pending
        if pending is None:
            # 保留原生派生入口的调用约定：调用本方法即请求衔接长按。
            # 主循环通常已在特殊 E 发键前建好凭据；直接恢复入口也必须
            # 在实际 key_down 之前获得同样的保护与异常清理能力。
            if not self._active():
                return False
            pending = self._new_forte_pending()
            self._forte_pending = pending
            self._followup = True
        # 热重载承接旧 pending 时补字段，原始持键锚点仍然保留，不重开预算。
        pending.setdefault('created_at', pending['hold_started'] if pending['hold_started'] is not None else time.time())
        pending.setdefault('attempt_started', pending['hold_started'])
        pending.setdefault('retries', 0)
        pending.setdefault('retry_hits', 0)
        pending.setdefault('released_at', pending['hold_limit'] if not pending['held'] else None)
        pending.setdefault('recovery_hits', 0)
        final_until = (pending['created_at'] + self.FORTE_INPUT_LIMIT
                       + self.FORTE_TAIL_HOLD + self.FORTE_RESTORE_TIMEOUT)
        start = time.time()
        try:
            while time.time() - start < min(self.FOLLOWUP_HOLD, self.WORK_SLICE):
                self.task.next_frame()
                if self._current_team_char(self) is not self:
                    return False
                self.check_combat()
                now = time.time()
                if (pending['hold_started'] is not None and pending['tail_started'] is None
                        and now - pending['hold_started'] >= self.FORTE_INPUT_LIMIT):
                    # HUD 暂缺也不能从下一工作片重新起算输入或收尾期限。
                    pending['tail_started'] = pending['hold_started'] + self.FORTE_INPUT_LIMIT
                    self.logger.warning('锁冥：原生 6s 输入观察已满，提示消耗尚未连续确认；'
                                        '按原锚点进入 3s 持键收尾，结束后仍须核实恢复')
                if (pending['held'] and pending['hold_limit'] is not None
                        and now >= pending['hold_limit']):
                    # 最大物理持键预算独立于 HUD；只释放输入，不伪造动作完成。
                    # 保留短期恢复观察；其后失败退出，而非永久占有全部输入。
                    self._release_forte_key()
                    self.logger.warning('锁冥：已到原生 6s 输入＋3s 收尾持键上限，'
                                        '先松 E，进入有限恢复观察')
                visible, index, _ = self.task.in_team()
                if now >= final_until:
                    # 其他槽位抖动、没有 HUD、甚至从未真正按下 E，都必须
                    # 能走到同一绝对出口，不能被后面的 continue 永久绕开。
                    if visible and index != self.index and self._reconcile_actor():
                        return False
                    return self._abandon_forte(pending, '派生总恢复观察期限已到')
                if visible and index != self.index:
                    # 只有稳定识别真实外换才解除本角色的输入所有权。
                    if self._reconcile_actor():
                        return False
                    pending['gone_hits'] = pending['back_hits'] = 0
                    continue
                if not visible:
                    if pending['held']:
                        pending['hidden_seen'] = True
                    pending['gone_hits'] = pending['back_hits'] = 0
                    pending['retry_hits'] = pending['recovery_hits'] = 0
                    self.sleep(self.POLL)
                    continue
                if pending['hold_started'] is None:
                    # 先记持键，确保底层发键后抛异常也能在异常路径释放。
                    # 只在本笔首次发 down 时建立锚点；换工作片不能延长预算。
                    pending['held'] = True
                    pending['hold_started'] = time.time()
                    pending['attempt_started'] = pending['hold_started']
                    pending['hold_limit'] = (pending['hold_started']
                                             + self.FORTE_INPUT_LIMIT + self.FORTE_TAIL_HOLD)
                    self.task.send_key_down(pending['key'])
                    self.logger.info('锁冥：后台持 E 输入段开始；先保持至少 2s，'
                                     '提示消耗后另走完整 3s 持键收尾，期间禁止其他动作')
                    pending['gone_hits'] = pending['back_hits'] = 0
                    continue
                full = self.forte_available() or self.is_e_forte_full()
                highlighted = self._e_highlighted()
                attempt_for = now - pending['attempt_started']
                retry_ready = (not pending['recorded'] and pending['tail_started'] is None
                               and full and highlighted and attempt_for >= self.FORTE_INPUT_HOLD)
                pending['retry_hits'] = pending['retry_hits'] + 1 if retry_ready else 0
                if (pending['retry_hits'] >= self.CONFIRM_FRAMES
                        and pending['retries'] < self.FORTE_START_RETRIES
                        and now + self.FORTE_REPRESS_RELEASE + self.FORTE_INPUT_HOLD
                            < pending['hold_started'] + self.FORTE_INPUT_LIMIT):
                    # 尚未消耗且 E 连续恢复可输入，才认为可以重试启动。
                    # 沿用原生松键再按，不根据单帧灰色取消已经进入的刻心念。
                    self._release_forte_key()
                    self.sleep(self.FORTE_REPRESS_RELEASE)
                    if self._current_team_char(self) is not self or not self._active():
                        return False
                    pending['retries'] += 1
                    pending['attempt_started'] = time.time()
                    pending['released_at'] = None
                    pending['retry_hits'] = pending['gone_hits'] = pending['back_hits'] = 0
                    pending['input_logged'] = False
                    pending['held'] = True
                    self.task.send_key_down(pending['key'])
                    self.logger.warning('锁冥：强化提示未消耗且 E 已恢复，有限重试刻心念启动；'
                                        '沿用原总期限，不增加持键上限')
                    continue
                if not highlighted and not pending['locked_seen']:
                    pending['locked_seen'] = True
                    self.logger.info('锁冥：E 白色像素线索已暗，仅记输入变化，不作为终结结束证据')
                pending['gone_hits'] = pending['gone_hits'] + 1 if not full else 0
                if pending['gone_hits'] >= self.CONFIRM_FRAMES and not pending['recorded']:
                    # 提示的连续消耗只证明本次 E/派生推进，不批准松键。
                    self.record_resonance_use()
                    pending['recorded'] = True
                    self._r_failures = 0
                    self._next_r = 0.0
                    self.logger.info('锁冥：强化 E 提示连续消耗，仅确认派生推进，继续持 E')
                held_for = now - pending['hold_started']
                if attempt_for >= self.FORTE_INPUT_HOLD and not pending['input_logged']:
                    pending['input_logged'] = True
                    self.logger.info(f'锁冥：原生 2s 输入保持已完成；已持 {held_for:.2f}s，'
                                     f'提示消耗={pending["recorded"]}，E泛白={highlighted}')
                if (pending['tail_started'] is None and attempt_for >= self.FORTE_INPUT_HOLD
                        and pending['recorded']):
                    pending['tail_started'] = now
                    self.logger.info('锁冥：进入原生完整 3s 持 E 收尾段；'
                                     f'提示消耗={pending["recorded"]}，E泛白不提前结束此段')
                tail_finished = (pending['tail_started'] is not None
                                 and now - pending['tail_started'] >= self.FORTE_TAIL_HOLD)
                restored = (tail_finished and highlighted
                            and pending['gone_hits'] >= self.CONFIRM_FRAMES)
                pending['back_hits'] = pending['back_hits'] + 1 if restored else 0
                if pending['back_hits'] >= self.CONFIRM_FRAMES:
                    self._release_forte_key()
                    self.logger.info(f'锁冥：原生输入／收尾预算已完成（{held_for:.2f}s），'
                                     '本角色 HUD、提示消耗及 E 恢复线索连续确认，已松 E；'
                                     '恢复 R／协奏决策（非专用终结形态识别）')
                    self._forte_pending = None
                    self._followup = False
                    self._lock_hint_since = None
                    return True
                if (not pending['held'] and pending['hold_limit'] is not None
                        and now >= pending['hold_limit']):
                    # 已走完原生最大输入／收尾预算。HUD 连续恢复后解除失败
                    # 步骤，不能再要求“E 必须亮且提示必须消耗”而永久锁住。
                    released_at = pending['released_at'] if pending['released_at'] is not None else pending['hold_limit']
                    recovered = now - released_at >= self.FORTE_RELEASE_SETTLE
                    pending['recovery_hits'] = pending['recovery_hits'] + 1 if recovered else 0
                    if pending['recovery_hits'] >= self.CONFIRM_FRAMES:
                        return self._abandon_forte(pending, '原持键上限已过，HUD 连续恢复但派生结果未确认')
                self.sleep(self.POLL)
        except BaseException:
            # 真正停止/异常必须释放物理按键；保留动作凭据，恢复运行后
            # 仍先核实本步骤，不能把异常当作允许 R/Q/切人的成功回执。
            self._release_forte_key()
            raise
        self.logger.debug('锁冥 E／刻心念阶段尚未完成，保留原始锚点与独占保护，'
                          f'持键={pending["held"]}，下一工作片继续观察')
        return False

    def _target_hsin(self):
        """兼容内部角色标识与脚本名定位心，目标缺失时不发切人键。"""
        return next((c for c in self.task.chars if c is not None
                     and (c.char_name == 'char_hsin' or c.name == 'Hsin')), None)

    @staticmethod
    def _same_team_char(left, right):
        """按角色标识与槽位核对身份，不把重载前后的实例当作两名角色。"""
        return (left is not None and right is not None
                and left.char_name == right.char_name and left.index == right.index)

    def _current_team_char(self, reference):
        """解析 task.chars 中当前生效的角色对象；身份缺失时不猜测目标。"""
        return next((char for char in self.task.chars
                     if self._same_team_char(char, reference)), None)

    def _start_handoff(self, source, target, con, unison_until=0.0):
        """冻结源资源快照后执行一组交棒输入，后续只恢复同一笔送达确认。

        可以由锁冥本人或心发起。有效同奏允许非满协奏交棒；普通交棒
        必须满协奏，并额外遵守锁冥再次交心的本轮 R／同奏条件。
        """
        # 协调器已被实时重载替换时，旧调用栈不再建立交棒或发送输入。
        if self._current_team_char(self) is not self:
            return False
        if self._pending is not None:
            return self._resume_handoff()
        source = self._current_team_char(source)
        target = self._current_team_char(target)
        if source is None or target is None or not self._active(source):
            return False
        if self._same_team_char(source, self) and self._forte_pending is not None:
            return False
        double_q = self._same_team_char(source, self)
        switch_margin = (self.SUOMING_UNISON_SWITCH_MARGIN if double_q
                         else self.UNISON_SWITCH_MARGIN)
        remaining = unison_until - time.time()
        if 0 < remaining < switch_margin:
            return False
        use_unison = unison_until > time.time()
        if not use_unison and con != 1:
            return False
        if self._same_team_char(source, self) and not use_unison and self._requires_r_before_outro():
            return False
        self.logger.info(f'心锁守：{source.name} → {target.name}，'
                         f'{"同奏" if use_unison else "满协奏"}交棒，源协奏 {con:.0%}'
                         f'{"，计划后台双短 Q 后立即切心" if double_q else ""}')
        # 日志／观测返回后再核对当前实例；全部准备必须在 Q 之前完成。
        if self._current_team_char(self) is not self:
            return False
        source = self._current_team_char(source)
        target = self._current_team_char(target)
        if source is None or target is None:
            return False
        self._pending = {'source': source, 'target': target, 'con': con,
                         'unison': use_unison, 'unison_timely': False,
                         'until': unison_until, 'last_send': time.time(),
                         'ack_until': time.time() + self.INTRO_GUARD}
        # until 是同奏效力期限，ack_until 是等待延迟送达证据的期限；
        # 两者不能混用，更不能因重试把同奏有效期向后顺延。
        # 切人输入截止后仍给末次输入一次 .4s 回执观察，保护与票据同锚，不能续期。
        self._guard_until = self._pending['ack_until'] + self.R_NO_ANIMATION_GRACE
        slot = target.index + 1
        # 每笔交接只执行这一组动作；重试只进入 _resume_handoff，不重发 Q。
        # 锁冥收招边缘单发可能未受理，有限补一次独立短按，不验声骸效果。
        # 心已取消收尾 E；所有交接末次 Q 后直接数字键，不能插入其他技能、
        # 读屏、记账、日志或 sleep。
        try:
            if double_q:
                source.send_echo_key(down_time=self.Q_TAP, interval=0,
                                     after_sleep=self.Q_RETRY_GAP)
                source.send_echo_key(down_time=self.Q_TAP, interval=0)
            else:
                source.send_echo_key(down_time=self.Q_TAP)
        except BaseException:
            self._pending = None
            self._guard_until = 0.0
            raise
        self.task.send_key(slot, down_time=self.SWITCH_TAP)
        self._pending['unison_timely'] = not use_unison or time.time() <= unison_until
        if double_q:
            self.logger.info('心锁守：锁冥后台双短 Q 调用已完成并已发送切心键；'
                             '仅记录动作，未验证声骸效果')
        return self._resume_handoff()

    def _resume_handoff(self):
        """核实待确认交棒的目标槽位，成功后一次性更新资源、变奏和轮次。

        目标连续可见才提交；源仍在场且窗口允许时只补数字键。工作片结束
        仍保留原票据，但绝对送达期限耗尽后解除失败票据，不能永久只补数字键。
        """
        pending = self._pending
        if pending is None:
            return False
        if self._current_team_char(self) is not self:
            return False
        start, hits, source_hits, other_hits, other_index = time.time(), 0, 0, 0, None
        while time.time() - start < self.SWITCH_TIMEOUT:
            self.task.next_frame()
            # 截止帧先核实实际角色，不能让长索敌抢走失败解除的控制权。
            if time.time() < pending['ack_until']:
                self.check_combat()
            # UI 实时重载浅复制 __dict__，不会像 load_chars 随后 reset_state。
            # 每次新帧后都重绑双方，避免循环中途重载后继续写旧对象，或把
            # task.chars 的 is_current_char 全部清空。协调器自身已换则让出，
            # 由新实例续接共享的 pending；这不是 GUI 并发操作的全局线程锁。
            if self._current_team_char(self) is not self:
                return False
            source = self._current_team_char(pending['source'])
            target = self._current_team_char(pending['target'])
            if source is None or target is None:
                # Q／数字键可能已发送，保留快照等身份恢复；不能清掉后重发 Q，
                # 更不能对缺失对象发补键或提交成功交棒。
                if time.time() >= pending['ack_until'] + self.R_NO_ANIMATION_GRACE:
                    self._cancel_handoff(pending, '送达期限已到且角色身份未恢复')
                return False
            pending['source'], pending['target'] = source, target
            visible, index, _ = self.task.in_team()
            if visible and index == target.index:
                source_hits = 0
                other_hits, other_index = 0, None
                hits += 1
                if hits >= self.CONFIRM_FRAMES:
                    # pending 是局部快照：source.switch_out 可能清除对象的
                    # 驻场字段，后面的记账仍必须使用发键前捕获的资源条件。
                    con = pending['con']
                    uncertain = pending['unison'] and not pending['unison_timely']
                    unison = pending['unison'] and not uncertain
                    intro = unison or con == 1
                    source.current_con = con
                    source.switch_out(con_full=intro and not unison)
                    if unison:
                        source.current_con = con
                    now = time.time()
                    if intro:
                        source.last_outro_time = now
                        if source.buff_time > 0:
                            source.last_buff_time = now
                    for char in self.task.chars:
                        if char is not None:
                            char.is_current_char = char is target
                    target.has_intro = intro
                    target.has_sub_dps_intro = intro and source.is_sub_dps
                    target.last_switch_in_time = now
                    # 迟发但已送达的切换保留入场保护，却不能凭原同奏计划
                    # 声称获得强化。回调的 None 专门表示这类证据不确定。
                    target._team_entry_guard_until = now + self.INTRO_GUARD if intro or uncertain else 0.0
                    if intro:
                        self.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
                    self._pending = None
                    self._guard_until = 0.0
                    if self._same_team_char(source, self):
                        if uncertain:
                            # 输入发送已跨过有效期，不能把可能的普通切换记成强化交棒。
                            self.round_phase = 'hsin_unison_recovery'
                        else:
                            self.outro_count += 1
                            if unison:
                                self.round_unison_outros += 1
                            self.round_phase = 'hsin_first' if self.outro_count == 1 else 'hsin_late'
                    else:
                        self.round_phase = 'keeper' if target.char_name == 'char_shorekeeper' else 'suoming_return'
                    on_intro = getattr(target, 'on_team_intro', None)
                    if callable(on_intro) and (intro or uncertain):
                        on_intro(None if uncertain else unison)
                    return True
            else:
                hits = 0
                if visible and index == source.index:
                    other_hits, other_index = 0, None
                    source_hits += 1
                    if pending['unison'] and time.time() >= pending['until']:
                        # 没确认切过去且同奏已过期，不再发可能没有延奏的数字键。
                        if source_hits >= self.CON_FRAMES and time.time() >= pending['ack_until']:
                            self._cancel_handoff(pending, '切人未送达且同奏已过期，未记作成功延奏')
                            return False
                    elif (time.time() - pending['last_send'] >= self.SWITCH_RETRY
                          and time.time() < pending['ack_until']
                          and (not pending['unison'] or
                               pending['until'] - time.time() >= self.SWITCH_TAP)):
                        self.task.send_key(target.index + 1, down_time=self.SWITCH_TAP)
                        pending['unison_timely'] = not pending['unison'] or time.time() <= pending['until']
                        pending['last_send'] = time.time()
                else:
                    source_hits = 0
                    if visible:
                        # 第三角色也须稳定多帧才交还调度；无 HUD 仅表示未知，
                        # 不提交任何角色或成功延奏推断。
                        other_hits = other_hits + 1 if index == other_index else 1
                        other_index = index
                        if other_hits >= self.CON_FRAMES:
                            for char in self.task.chars:
                                if char is not None:
                                    char.is_current_char = char.index == index
                            source.has_intro = source.has_sub_dps_intro = False
                            self._clear_visit()
                            return False
                    else:
                        other_hits, other_index = 0, None
            if time.time() >= pending['ack_until'] + self.R_NO_ANIMATION_GRACE:
                self._cancel_handoff(pending, '绝对送达期限已到，未取得连续目标槽位回执')
                return False
            self.sleep(self.POLL)
        return False

    def _cancel_handoff(self, pending, reason):
        """撤销失败交棒，不提交延奏、变奏、资源消耗或轮次成功。"""
        if self._pending is not pending:
            return
        source = self._current_team_char(pending['source'])
        self._pending = None
        self._guard_until = 0.0
        if source is not None:
            source._action_recovery_until = time.time() + self.ACTION_RECOVERY_GUARD
        self.logger.warning(f'心锁守：{reason}；撤销旧交棒票据，按当前角色／实际资源重新判断')

    def handoff_from_hsin(self, source, unison_until):
        """心本次确认一段 R 后调用；不据已有后半形态推测同奏。

        有效窗口内直接使用心保存的资源快照，防止 OCR 消耗切人余量。
        若窗口不足则重新验证当前协奏，后续仅能依照真实条件决定是否交棒。
        """
        if self._pending is not None:
            return self._resume_handoff()
        source = self._current_team_char(source)
        if source is None or self.round_phase != 'hsin_first' or not self._active(source):
            return False
        if unison_until - time.time() >= self.UNISON_SWITCH_MARGIN:
            # 真实 R1 同奏已确认，源协奏快照只用于记账；这里不能再做 OCR。
            con = source.current_con
            if not isinstance(con, (float, int)) or not math.isfinite(con) or not 0 <= con <= 1:
                con = 0.0
            return self._start_handoff(source, self, con, unison_until)
        try:
            con = float(self.task.get_current_con())
        except (TypeError, ValueError):
            con = source.current_con if unison_until - time.time() >= self.UNISON_SWITCH_MARGIN else float('nan')
        if not math.isfinite(con) or not 0 <= con <= 1:
            return False
        return self._start_handoff(source, self, con, unison_until)

    def resume_hsin_handoff(self, source):
        """让心优先恢复自己发起的交棒；返回值表示该待确认步骤已接管调度。"""
        # 重载后的心也要接管旧实例发起的交棒，不能因对象 is 失配继续攻击。
        if self._pending is not None and self._same_team_char(self._pending['source'], source):
            self._resume_handoff()
            return True
        return False

    def handoff_to_keeper_from_hsin(self, source):
        """终结 R 真正完成且满协奏，才由心把下一轮交给守岸人。

        资格同时依赖 hsin_late 阶段、本次后半 R 施放标记与心仍在场。
        读取不可信或守岸人缺失时不创建交棒，不以缓存补造满协奏。
        """
        if self._pending is not None:
            return self._resume_handoff()
        source = self._current_team_char(source)
        if (source is None or self.round_phase != 'hsin_late' or not source.lib2_cast_this_turn
                or not self._active(source)):
            return False
        target = self._opening_keeper()
        try:
            con = float(self.task.get_current_con())
        except (TypeError, ValueError):
            return False
        if target is None or not math.isfinite(con) or con != 1:
            return False
        return self._start_handoff(source, target, con)

    def recover_hsin_handoff(self, source):
        """同奏送达不明时先稳妥回锁重新拿条件，不让心直接走未强化后半。

        本分支允许非满协奏普通切回，但不会由此声称获得变奏。心满协奏
        时才先补 Q；所有准备状态仍在 Q 前写好，随后立即发送切锁数字键。
        """
        if self.round_phase != 'hsin_unison_recovery':
            return False
        if self._current_team_char(self) is not self:
            return True
        source = self._current_team_char(source)
        if source is None:
            return True
        if not self._active(source):
            visible, index, _ = self.task.in_team()
            if visible and index == self.index:
                for char in self.task.chars:
                    if char is not None:
                        char.is_current_char = char is self
                self.round_phase = 'suoming_return'
            elif visible:
                self._reconcile_actor()
            return True
        self.task.next_frame()
        self.check_combat()
        if self._current_team_char(self) is not self:
            return True
        source = self._current_team_char(source)
        if source is None or not self._active(source):
            return True
        try:
            con = float(self.task.get_current_con())
        except (TypeError, ValueError):
            source.sleep(self.POLL)
            return True
        if not math.isfinite(con) or not 0 <= con <= 1:
            source.sleep(self.POLL)
            return True
        # OCR 也可能跨过实时重载；创建恢复交棒前只接受当前协调器和源对象。
        if self._current_team_char(self) is not self:
            return True
        source = self._current_team_char(source)
        if source is None:
            return True
        self._pending = {'source': source, 'target': self, 'con': con, 'unison': False,
                         'unison_timely': True, 'until': 0.0, 'last_send': time.time(),
                         'ack_until': time.time() + self.INTRO_GUARD}
        self._guard_until = self._pending['ack_until'] + self.R_NO_ANIMATION_GRACE
        if con == 1:
            try:
                source.send_echo_key(down_time=self.Q_TAP)
            except BaseException:
                self._pending = None
                self._guard_until = 0.0
                raise
            self.task.send_key(self.index + 1, down_time=self.SWITCH_TAP)
        else:
            self.task.send_key(self.index + 1, down_time=self.SWITCH_TAP)
        self._resume_handoff()
        return True

    def _reconcile_actor(self):
        """连续确认其他槽位实际在场后同步框架，清除不再属于锁冥的驻场步骤。"""
        visible, index, _ = self.task.in_team()
        if not visible or index == self.index:
            return False
        for _ in range(self.CONFIRM_FRAMES - 1):
            self.sleep(self.POLL)
            self.task.next_frame()
            again, actual, _ = self.task.in_team()
            if not again or actual != index:
                return False
        for char in self.task.chars:
            if char is not None:
                char.is_current_char = char.index == index
        self._clear_visit()
        return True

    def do_perform(self):
        """执行一个工作片：先恢复持 E／刻心念，再恢复交棒／R 和通常优先级。

        时间片结束只让出调度，未决证据和本轮计数继续保留。每次真正切人
        都由交棒方法统一确认并提交，避免普通分支自行推进轮次。
        """
        # E 衔接/刻心念是不可插队的子状态；连 R 可用性探测都须在其后。
        if self._forte_pending is not None:
            if not self._continue_forte():
                return
        if self._pending is not None:
            self._resume_handoff()
            return
        if self._reconcile_actor():
            return
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.WORK_SLICE:
            if self._forte_pending is not None:
                if not self._continue_forte():
                    return
                continue
            # 待确认 R 必须先恢复演出保护，再做可能判断脱战的逐帧检查。
            if self._r_pending is not None:
                if not self._cast_r():
                    return
                self._handoff_ready_unison()
                return
            if not self._frame():
                if self._reconcile_actor():
                    return
                self.sleep(self.POLL)
                continue
            if self._handoff_ready_unison():
                return
            # 最新要求：入场先看 R，不再先垫固定 1.6 秒普攻。
            if self._r_ready():
                if self._cast_r(ready_checked=True):
                    self._handoff_ready_unison()
                    return
                if self._r_pending is None:
                    self._attack()
                continue
            if not self._entry_done and not self._prepare_entry():
                return
            if self._locked():
                # 锁定线索只在有限等待内阻止抢切；可继续普攻探测，不能
                # 用单帧 E 变暗认定派生完成，也不能永久卡住满协奏路径。
                if self._lock_hint_since is None:
                    self._lock_hint_since = time.time()
                if time.time() - self._lock_hint_since < self.ACTION_WAIT:
                    # 不抢切可能的刻心念，但允许普攻补能；真硬直由客户端拒绝输入。
                    self._attack()
                    continue
            else:
                self._lock_hint_since = None
            con = self._read_con()
            if con is None:
                self.sleep(self.POLL)
                continue
            if self._unison_until > time.time():
                # 剩余同奏不足安全切键余量时等其结束，不把它降级成
                # 同一瞬间的普通满协奏交棒，避免错误归因延奏类型。
                self.sleep(self.POLL)
                continue
            if con == 1 and self._full_con():
                # 满协奏确认的几帧里 R 可能刚解锁，仍优先 R。正、负结果
                # 都须连续确认；之前巡检的单帧否与重试节流不能批准普通交棒。
                ready = self._r_ready(before_outro=True)
                observation = self._r_observation
                samples = ', '.join(f'亮={int(highlighted)}/CD={cd:.2f}s'
                                    for highlighted, cd in observation['samples']) or '未采样'
                self.logger.info(f'心锁守：锁冥满协奏交棒前 R复核={observation["result"]}；'
                                 f'{samples}；协奏={self.current_con:.0%}，'
                                 f'R开关={self.task.use_liberation}，失败={self._r_failures}，'
                                 f'重试余量={max(0.0, self._next_r - time.time()):.2f}s')
                if ready:
                    if self._cast_r(ready_checked=True):
                        self._handoff_ready_unison()
                        return
                    if self._r_pending is None:
                        self._attack()
                    continue
                if (observation['result'] in ('unavailable', 'disabled', 'exhausted')
                        and not self._requires_r_before_outro()):
                    self._start_handoff(self, self._target_hsin(), self.current_con)
                    return
                # R 混合读数／退避不能批准普通延奏，也不能让 E 解锁与普攻
                # 永远没有执行机会。交给下面的实际 E／回路／A 分支继续恢复。
            if self._followup:
                self._continue_forte()
            elif time.time() >= self._next_e and (self.forte_available() or self.is_e_forte_full()):
                if not self._use_e(special=True) and self._forte_pending is None:
                    self._attack()
            elif (not self._save_e_for_forte() and time.time() >= self._next_e
                  and self.task.available(
                      'resonance', check_color=True, check_cd=True)):
                if not self._use_e() and self._forte_pending is None:
                    self._attack()
            else:
                self._attack()
        self.logger.debug('锁冥时间片结束，未取得有效延奏条件，保留进度继续留场')
