import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Aemeath(BaseChar):
    LIBERATION_COOLDOWN = 25
    LIBERATION_FORCE_DURATION = 30
    LIB2_PREPARE_WINDOW = 8
    INTRO_LIBERATION_DELAY = 14
    # 每次上场至少打这么久 (秒), 有资源要等时最多延长到 FIELD_WAIT_TIME
    FIELD_MIN_TIME = 1.2
    FIELD_WAIT_TIME = 3.6
    # 吃到变奏入场后先普攻的时长 (秒)
    INTRO_ATTACK_TIME = 1.2
    # 重击松开后到闪避之前的等待 (秒), 闪避过早打断伤害时调大
    HEAVY_DODGE_DELAY = 0.05
    # 开场一炮后原地等待确认战斗是否结束的时长 (秒), 敌人还活着就照常继续
    POST_HEAVY_COMBAT_CHECK = 1.5
    # 新战斗第一次出手时如果是人形态 (F 吸收声骸会把机兵变回人), 先按 E 切回机兵形态再开炮
    ENSURE_MECH_FORM_ON_NEW_COMBAT = True
    # 按 E 后等待变成机兵形态的最长时间 (秒)
    MECH_SWITCH_TIME_OUT = 1.5
    # 变成机兵后等待强化重击图标出现的最长时间 (秒)
    MECH_HEAVY_WAIT = 0.8

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.should_wait = False
        self.last_liber = -1
        self.last_enhance_e = -1
        self.intro_liberation_time = -1
        self.pending_lib2 = False
        self.last_combat_start = -1

    # ---- 大招节奏 (参照创意工坊爱达千队爱弥斯的通用分支) ----
    # R1 只在吃到变奏后的 INTRO_LIBERATION_DELAY 秒内放, 或者距上次 R2 (或开战) 超过
    # LIBERATION_FORCE_DURATION 秒强制放; R2 亮了就放; R2 快转好时不切人, 等它出来

    def lib2_cooldown_anchor(self):
        if self.last_liber >= 0:
            return self.last_liber
        combat_start = getattr(self.task, 'combat_start', -1)
        return combat_start if combat_start > 0 else -1

    def lib2_cooldown_left(self):
        anchor = self.lib2_cooldown_anchor()
        if anchor < 0:
            return 0
        return max(0, self.LIBERATION_COOLDOWN - self.time_elapsed_accounting_for_freeze(anchor))

    def liberation_cooldown_left(self):
        if self.last_liber < 0:
            return 0
        return max(0, self.LIBERATION_COOLDOWN - self.time_elapsed_accounting_for_freeze(self.last_liber))

    def record_intro_liberation(self):
        self.intro_liberation_time = time.time()

    def intro_lib1_ready(self):
        return self.intro_liberation_time >= 0 and (
                self.time_elapsed_accounting_for_freeze(self.intro_liberation_time) <= self.INTRO_LIBERATION_DELAY)

    def lib1_unlocked(self):
        if self.intro_lib1_ready():
            return True
        anchor = self.lib2_cooldown_anchor()
        return anchor >= 0 and self.time_elapsed_accounting_for_freeze(anchor) >= self.LIBERATION_FORCE_DURATION

    def can_cast_lib1(self):
        return self.liberation_cooldown_left() <= 0 and self.lib1_unlocked()

    def lib2_available(self):
        return bool(self.task.find_one('aemeath_lib2', threshold=0.7))

    def preparing_lib2(self):
        return self.lib2_cooldown_anchor() >= 0 and self.lib2_cooldown_left() < self.LIB2_PREPARE_WINDOW

    def should_wait_for_lib2(self):
        return self.pending_lib2 or self.preparing_lib2()

    def should_wait_for_enhance_e(self):
        return self.time_elapsed_accounting_for_freeze(self.last_enhance_e) > 12

    def record_enhance_e(self):
        self.last_enhance_e = time.time()

    def record_liberation(self, is_lib2):
        if is_lib2:
            self.pending_lib2 = False
            self.last_liber = time.time()
            self.last_enhance_e = self.last_liber
        else:
            self.intro_liberation_time = -1

    def do_perform(self):
        first_turn_this_combat = self.last_combat_start != self.task.combat_start
        self.last_combat_start = self.task.combat_start
        if first_turn_this_combat and not self.has_intro:
            self.opening_shot()
        self.should_wait = False
        if self.has_intro:
            self.record_intro_liberation()
            self.continues_normal_attack(self.INTRO_ATTACK_TIME)
        self.perform_everything()
        self.switch_next_char()

    def opening_shot(self):
        """新战斗开场: 确认机兵形态 -> 强化重击 -> 闪避 -> 停手确认敌人是否已倒下。

        敌人倒下时 check_combat 抛出脱战异常, 战斗任务停下来等下一轮; 还活着就回到正常循环。
        """
        if self.ENSURE_MECH_FORM_ON_NEW_COMBAT:
            self.ensure_mech_form()
        if self.handle_heavy():
            start = time.time()
            while time.time() - start < self.POST_HEAVY_COMBAT_CHECK:
                self.check_combat()
                self.sleep(0.1)

    def lib(self):
        is_lib2 = self.lib2_available()
        if not is_lib2 and not self.can_cast_lib1():
            return False
        if not self.click_liberation(wait_if_cd_ready=0):
            return False
        self.record_liberation(is_lib2)
        self.f_break()
        return True

    def perform_everything(self):
        start = time.time()
        self.should_wait = self.should_wait_for_lib2() or self.should_wait_for_enhance_e()
        if not self.should_wait:
            self.should_wait = self.has_intro and self.liberation_cooldown_left() < 12
        while self.time_elapsed_accounting_for_freeze(start) < self.FIELD_MIN_TIME or (
                self.should_wait and self.time_elapsed_accounting_for_freeze(start) < self.FIELD_WAIT_TIME):
            self.cycle_start()
            if self.handle_heavy():
                self.f_break()
                start = time.time()
                self.should_wait = self.should_wait_for_lib2()
                self.task.next_frame()
                continue
            if self.intro_lib1_ready() and self.lib():
                start = time.time()
                self.should_wait = self.should_wait_for_lib2()
            elif self.enhance_e_available():
                if self.click_resonance(has_animation=True, send_click=True, animation_min_duration=0.5,
                                        time_out=1.5)[0]:
                    self.record_enhance_e()
                    self.click_echo(time_out=0)
                    self.f_break()
                    self.task.next_frame()
                if (self.intro_lib1_ready() and self.can_cast_lib1() and self.liberation_available()) or \
                        self.has_long_action():
                    start = time.time()
                else:
                    self.click(after_sleep=0.01)
                    return
            elif self.lib():
                start = time.time()
                self.should_wait = self.should_wait_for_lib2()
                continue
            else:
                self.click()
            self.cycle_sleep()

    def enhance_e_available(self):
        return self.task.find_one('aemeath_e1', threshold=0.7) or self.task.find_one('aemeath_e2',
                                                                                     threshold=0.7)

    def in_human_form(self):
        return bool(self.task.find_one('aemeath_human_heavy', threshold=0.7))

    def ensure_mech_form(self):
        """人形态时按一次 E 切到机兵形态, 再等强化重击图标出现。"""
        if not self.in_human_form():
            return True
        self.logger.info('new combat in human form, press E to switch to mech form')
        self.send_resonance_key()
        if not self.task.wait_until(lambda: not self.in_human_form(), time_out=self.MECH_SWITCH_TIME_OUT):
            self.logger.warning('switch to mech form timed out')
            return False
        self.task.wait_until(self.has_long_action, time_out=self.MECH_HEAVY_WAIT)
        return True

    def heavy_wait_highlight_down(self):
        self.task.mouse_down()
        try:
            ret = self.task.wait_until(lambda: not self.has_long_action(), time_out=1.2)
        finally:
            self.task.mouse_up()
        self.sleep(0.01, check_combat=False)
        return ret

    def handle_heavy(self):
        if not self.has_long_action():
            return False
        prepares_lib2 = self.preparing_lib2()
        if self.heavy_wait_highlight_down():
            if prepares_lib2:
                self.pending_lib2 = True
            # R2 亮着时直接接 R2 打断后摇, 不闪避
            if not self.lib2_available():
                self.dodge_cancel()
            return True
        return False

    def dodge_cancel(self):
        """重击打出后点按右键闪避, 打断后摇。"""
        self.sleep(self.HEAVY_DODGE_DELAY, check_combat=False)
        self.task.click(key='right', down_time=0.01)
        self.logger.debug('heavy attack dodge cancel')

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self.should_wait_for_lib2():
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        # 留在场上, 下一轮战斗由爱弥斯重击开场
        self.logger.info('combat end, Aemeath stays on field for the next round')
