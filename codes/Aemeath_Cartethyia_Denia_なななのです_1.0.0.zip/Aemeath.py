import time

from src.char.BaseChar import BaseChar


class CannonReady(Exception):
    """爱弥斯在任意一步里发现机兵形态的强化重击已经亮了: 中断这一步, 先开炮 + R2, 再从循环开头接着打。"""


class Aemeath(BaseChar):
    """爱/卡/达队的爱弥斯: 和达妮娅按一份共用的步骤表轮流出手, 卡提希娅不上场。

    步骤表 (用户给的手法, 2026-10-18):
      开场 (新战斗):  爱 开炮+闪避 -> 达 普攻1秒(确认还在战斗) R1 A1234 E1 E2 R2 Q -> 爆发
      循环 (R2 之后): 爱 E 变机兵 -> 达 变奏入场 -> 爱 A2A3A4 普通E -> 达 普攻1秒 E -> 爱 普攻到强化E 放掉再点一下A
                      -> 达 (R1) A1234 E1 E2 R2 Q -> 爆发
      爆发 (达妮娅延奏后): 爱 普攻到强化E 亮(先不放) -> Q -> R1 -> 强化E -> 普攻到强化E 再亮 -> 强化E
                      -> 确认机兵形态 -> 开炮 -> R2
    大流程: 爱 R2 -> 达 R1 -> 达 E1E2 -> 达 R2Q (延奏) -> 爱爆发。强化重击 (炮) 要靠达妮娅 R2 的延奏才会亮,
    所以达妮娅那一段一次打完, 不再在 E1/E2 中间切回爱弥斯 (实测太容易接不上, 用户 2026-10-18 决定放弃)。
    普通E 绝对不能打成强化E: 按之前窗口亮着就不按。
    开炮优先级最高: 不管轴乱到哪一步, 只要机兵形态的强化重击亮了, 就开炮 + R2, 从循环开头重新对齐 (CannonReady)。
    R 不用框架的 click_liberation: 它只在"解放可用"检测通过时才按, 技能动画里那个检测常常不过, 结果一下都不按。
    步骤名 aem_ 开头的由爱弥斯执行, den_ 开头的由达妮娅执行 (见 Denia.py), 执行完切给下一步的人。
    """
    # 重击松开后到闪避之前的等待 (秒), 闪避过早打断伤害时调大
    HEAVY_DODGE_DELAY = 0.05
    # 新战斗第一次出手时如果是人形态 (F 吸收声骸会把机兵变回人), 先按 E 切回机兵形态再开炮
    ENSURE_MECH_FORM_ON_NEW_COMBAT = True
    # 按 E 后等待变成机兵形态的最长时间 (秒)
    MECH_SWITCH_TIME_OUT = 1.5
    # 变成机兵后等待强化重击图标出现的最长时间 (秒)
    MECH_HEAVY_WAIT = 0.8

    OPENER = ('aem_open', 'den_open', 'aem_burst')
    LOOP = ('aem_post_r2', 'den_intro', 'aem_a234_e', 'den_a_e', 'aem_until_enh', 'den_r1_e1e2_r2_q',
            'aem_burst')
    # 普攻点击间隔 (秒)
    A_INTERVAL = 0.12
    # "A2A3A4 再 E": 连续普攻这么久保证 A4 打出来再按 E (秒)。A4 还没出来就按了 E 时调大
    AEM_A234_TIME = 1.4
    # Q (声骸) 连按到进冷却的最长时间 (秒), 爆发里 R1 前按; 达妮娅 R2 后也用这个
    ECHO_TIME_OUT = 1.0
    # R2 之后等演出结束 (队伍 HUD 回来) 再按 E 变机兵的最长时间 (秒)
    POST_R2_HUD_WAIT = 6.0
    # R2 落地后连点 E: 每隔 POST_R2_E_GAP 秒点一下, 一共点 POST_R2_E_PRESSES 下 (落地时单按一下容易被吞)
    POST_R2_E_GAP = 0.15
    POST_R2_E_PRESSES = 4
    # 普攻等强化E 亮起的最长时间 (秒), 等不到就跳过这一下
    ENHANCE_E_WAIT = 6.0
    # 爆发里 R1 后等强化E 亮起、普攻到强化E 再亮起的最长时间 (秒)
    BURST_E_WAIT = 3.0
    BURST_E3_WAIT = 4.0
    # R1 放出来之后, 打空等强化E / 炮 / R2 的最长时间 (秒): R1 放了就一定要打完 R2 才走
    AFTER_R1_WAIT = 20.0
    # 第 3 次强化E 之后等机兵强化重击图标的时间 (秒): 先等第一段, 等不到就按 E 换形态再等第二段
    # (人形态但人形态重击图标没亮时认不出形态, 炮在机兵形态才出现)
    CANNON_WAIT = 0.8
    CANNON_WAIT_AFTER_E = 1.5
    # 开炮后等 R2 图标 (aemeath_lib2) 的最长时间 (秒)
    R2_ICON_WAIT = 1.5
    # 连按 R 直到演出开始 (队伍 HUD 消失) 的最长时间 (秒), 演出期间每 0.1 秒按 F 接处决
    LIB_TIME_OUT = 1.5
    LIB_KEY_INTERVAL = 0.1
    # 按完 R 后再等这么久看过场有没有开始 (秒): 过场可能晚一点才开始, 这段时间仍然算"大招中"
    LIB_GRACE = 0.5
    # 达妮娅 R2 不隐藏 HUD 时, R2 图标要连续这么多次认不到才算放出来 (图标短暂闪一下会误判)
    LIB_FIRED_CHECKS = 3
    # 要放 R1 时 R1 没好就一直普攻, 边打边试 R, 最多这么久 (秒)。用户: "到了要按 R1 的时候能量没满, 多平A总是对的"
    R1_ENERGY_WAIT = 8.0
    # 边打边试 R1: 解放图标亮着时每隔 R1_TRY_GAP 秒试一次, 每次连按 R1_TRY_TIME 秒;
    # 图标一直不亮也每隔 R1_BLIND_GAP 秒盲试一次 (图标识别不准时)
    R1_TRY_GAP = 0.3
    R1_TRY_TIME = 0.6
    R1_BLIND_GAP = 2.0
    # 开炮预输入: 第 3 次强化E 演出开始后过这么久就按住左键 (秒), 演出提前结束就在结束时按住。
    # 按得太早会被吞, 太晚就是演出后再起手; 炮出不来先调这个
    CANNON_PREHOLD_AFTER = 2.0
    # 按住左键等炮打出去 (炮图标亮过又灭) 的最长时间 (秒)
    CANNON_HOLD_MAX = 3.0

    # 强化E 窗口: A4 抬手时资源条够就亮起, 实测约 5 秒 (7 次里 6 次 4.93~5.32 秒, 矩阵计时器核对一次 5.03 秒),
    # 人形态和机兵形态一样, 期间没有时停; 过了要等下一个 A4。
    # 图标亮着就还在窗口里, 每按一次等 ENHANCE_E_CONFIRM_TIME 秒看放没放出来, 最多按 ENHANCE_E_PRESSES 次
    ENHANCE_E_CONFIRM_TIME = 0.6
    ENHANCE_E_PRESSES = 4
    # 图标在白色/橙色发光之间变化或有特效闪过时, 模板会短暂认不出 (实测 0.09~0.23 秒)。
    # 连续这么久认不出才算图标真的灭了 (秒)
    ENHANCE_E_DROPOUT = 0.3
    # 这个窗口没放出来时, 等图标灭掉 (等下一个 A4) 再试; 图标一直不灭就最多等这么久 (秒), 要比窗口长
    ENHANCE_E_RETRY_COOLDOWN = 5.5
    # 强化E 演出的最长时间 (秒)
    ENHANCE_E_ANIM_TIME_OUT = 6.0

    # 测量模式: 改成 True 后爱弥斯在场时只普攻、不按 E, 图标一亮就停手看它自己灭掉,
    # 日志里记下每个强化E 窗口亮了多久。测完改回 False
    MEASURE_ENHANCE_E_WINDOW = False
    # 测量模式下一次上场测多久 (秒)
    MEASURE_TIME = 30.0
    # 图标亮起后最多等它灭掉多久 (秒), 超过说明模板一直匹配, 不是窗口图标
    MEASURE_LIT_TIME_OUT = 10.0
    # 测量时把前几个窗口亮起那一帧和熄灭那一帧存成图片 (working/screenshots/aemeath_measure/),
    # 用来对照矩阵模式顶部计时器的游戏内时间。0 表示不存
    MEASURE_SAVE_WINDOWS = 5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_enhance_e = -1
        self.last_combat_start = -1
        self.enhance_e_blocked_until = 0
        self.enhance_e_last_lit = 0
        self.seq = self.OPENER
        self.pos = 0
        self.watch_cannon = False
        self.r1_this_loop = False

    # ---- 步骤表 (达妮娅也通过这几个方法读写) ----

    def step(self):
        return self.seq[self.pos]

    def next_step(self):
        self.pos += 1
        if self.pos >= len(self.seq):
            self.seq, self.pos = self.LOOP, 0
        self.logger.info(f'step -> {self.step()}')

    def denia(self):
        for char in self.task.chars:
            if char is not None and char is not self and char.char_name == 'char_denia':
                return char
        return None

    def do_perform(self):
        if self.MEASURE_ENHANCE_E_WINDOW:
            self.measure_enhance_e_window()
            return self.switch_next_char()
        if self.last_combat_start != self.task.combat_start:
            self.last_combat_start = self.task.combat_start
            self.seq, self.pos = self.OPENER, 0
            self.r1_this_loop = False
            self.logger.info(f'new combat, step -> {self.step()}')
        while True:
            step = self.step()
            if step.startswith('den_'):
                if self.denia() is not None:
                    return self.switch_next_char()
                self.logger.info(f'no Denia in team, skip {step}')
                self.next_step()
                continue
            # 开场那一炮和爆发自己处理: 爆发里炮在 R1 强化E A234 时就已经好了, 但要留到第 3 次强化E 之后、
            # R2 之前再放 (用户 2026-10-18); 其余步骤里一旦看到机兵强化重击就中断, 先开炮 + R2 重新对齐
            self.watch_cannon = step not in ('aem_open', 'aem_burst')
            try:
                getattr(self, step)()
            except CannonReady:
                self.logger.info(f'cannon ready during {step}, cannon + R2 and restart the loop')
                self.cannon_and_r2()
                self.seq, self.pos = self.LOOP, 0
                self.logger.info(f'step -> {self.step()}')
                continue
            finally:
                self.watch_cannon = False
            self.next_step()

    # ---- 爱弥斯的步骤 ----

    def aem_open(self):
        """开场: 确认机兵形态 -> 强化重击 -> 闪避, 不停留, 直接交给达妮娅 (她先确认还在不在战斗)。"""
        if self.ENSURE_MECH_FORM_ON_NEW_COMBAT:
            self.ensure_mech_form()
        self.handle_heavy()

    def aem_post_r2(self):
        """R2 之后是人形态: 演出结束落地后多点几下 E 变机兵 (用户 2026-10-19: "R2 落地后多点几下 E 就行,
        剩下的靠兜底")。落地时 E 容易被吞, 实测只按一下、34 毫秒后就切人时 E 没出来, 达妮娅少了变奏。"""
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_R2_HUD_WAIT)
        for _ in range(self.POST_R2_E_PRESSES):
            self.send_resonance_key()
            self.sleep(self.POST_R2_E_GAP, check_combat=False)
        self.record_resonance_use()

    def aem_a234_e(self):
        self.attack_for(self.AEM_A234_TIME)
        self.normal_e()

    def aem_until_enh(self):
        """普攻到强化E 亮起放掉, 再点一下普攻。"""
        if self.spin_until(self.enhance_e_ready, self.ENHANCE_E_WAIT) and self.try_enhance_e():
            self.logger.info('enhance E #1')
        else:
            self.logger.info('enhance E #1 not available, move on')
        self.click()

    def aem_burst(self):
        """达妮娅延奏之后: 普攻到强化E 亮 (先不放) -> Q -> R1 -> 强化E -> 普攻到强化E 再亮 -> 强化E
        -> 确认机兵形态 -> 开炮 -> R2。

        R1 放了就一定要打完 R2 才能走 (用户 2026-10-19): 怪死光打空时强化E 起不来, 就一直普攻等下一波,
        最后还没放出 R2 就由 finish_r2_after_r1 兜底。"""
        self.burst_body()
        if self.r1_this_loop:
            self.finish_r2_after_r1()

    def burst_body(self):
        self.logger.info(f'burst start (intro={self.has_intro})')
        start = time.time()
        lit = self.spin_until(self.enhance_e_ready, self.ENHANCE_E_WAIT)
        self.logger.info(f'burst: enhance E {"lit" if lit else "NOT lit"} after attacking {time.time() - start:.1f}s')
        self.fire_echo()
        # R1 没好 (能量没满或冷却) 就边普攻边试; 不用 has_cd 跳过, 它实测会误判
        if not self.lib2_available() and self.attack_until_lib():
            self.r1_this_loop = True
            self.logger.info('burst: R1')
        for n, wait in ((2, self.BURST_E_WAIT), (3, self.BURST_E3_WAIT)):
            prehold = n == 3
            if self.r1_this_loop:
                # R1 都放了: 强化E 起不来 (比如怪死光打空) 也接着普攻等, 不早早放弃
                wait = self.AFTER_R1_WAIT
            if self.spin_until(self.enhance_e_ready, wait) and self.try_enhance_e(prehold=prehold):
                self.logger.info(f'burst: enhance E #{n}')
                if prehold:
                    # 第 3 次强化E 演出末尾已经按住左键, 等炮打出去
                    self.watch_cannon = False
                    if self.hold_cannon():
                        self.logger.info('burst: cannon (pre-input)')
                        return self.r2_after_cannon()
            else:
                self.logger.info(f'burst: enhance E #{n} not available')
        self.watch_cannon = False
        if self.lib2_available():
            # 炮在 HUD 不可见时打出去了, 没看到图标, 但 R2 已经亮了
            return self.r2_after_cannon()
        # 开炮要在机兵形态。人形态时额外动作格亮的是人形态重击; 人形态重击图标没亮时又认不出形态,
        # 所以等不到炮就按一下 E 换形态再等
        pressed_e = self.in_human_form() and self.normal_e()
        if self.spin_until(self.cannon_ready, self.CANNON_WAIT_AFTER_E if pressed_e else self.CANNON_WAIT,
                           click=False):
            return self.cannon_and_r2()
        if not pressed_e and self.normal_e() and self.spin_until(self.cannon_ready, self.CANNON_WAIT_AFTER_E,
                                                                 click=False):
            return self.cannon_and_r2()
        self.logger.info('burst: cannon not available')

    # ---- 共用的动作 ----

    def cannon_ready(self):
        """机兵形态的强化重击亮着: 额外动作格有图标, 而且不是人形态重击。"""
        return bool(self.has_long_action()) and not self.in_human_form()

    def check_cannon(self):
        """开炮优先, 但前提是炮后接得上 R2: 这一轮 R1 已经放过, 或者 R2 图标已经亮了。
        R1 之前就开炮会把炮白打掉, 爆发里 R1、强化E 也都跳过了。"""
        if self.watch_cannon and self.cannon_ready() and (self.r1_this_loop or self.lib2_available()):
            raise CannonReady()

    def cannon_and_r2(self):
        self.watch_cannon = False
        if self.handle_heavy():
            self.logger.info('cannon')
        self.r2_after_cannon()

    def r2_after_cannon(self):
        if self.spin_until(self.lib2_available, self.R2_ICON_WAIT, click=False) and self.fire_liberation():
            self.logger.info('R2')
            self.r1_this_loop = False
            return True
        self.logger.info('R2 not available after cannon')
        return False

    def finish_r2_after_r1(self):
        """R1 放了但 R2 还没放出来: 一直普攻, 强化E 亮就放、炮亮就开、R2 亮就放, 放出 R2 才走。
        人形态时炮出不来, 认得出人形态就隔一会儿按一下 E 换成机兵。最多 AFTER_R1_WAIT 秒 (脱战会由框架打断)。"""
        self.logger.info('R1 used but R2 not yet: keep attacking until R2')
        self.watch_cannon = False
        start = time.time()
        last_toggle = 0
        while time.time() - start < self.AFTER_R1_WAIT:
            if self.lib2_available():
                if self.fire_liberation(click=True):
                    self.logger.info(f'R2 after {time.time() - start:.1f}s of extra attacking')
                    self.r1_this_loop = False
                    return True
            elif self.cannon_ready():
                if self.handle_heavy():
                    self.logger.info('cannon (finishing after R1)')
            elif self.enhance_e_ready():
                self.try_enhance_e()
            elif self.in_human_form() and time.time() - last_toggle >= 2.0 and self.normal_e():
                last_toggle = time.time()
            self.click()
            self.sleep(self.A_INTERVAL)
        self.logger.info(f'R2 still not out after {self.AFTER_R1_WAIT:.0f}s of extra attacking')
        return False

    def hold_cannon(self):
        """左键已经按住 (try_enhance_e 预输入的): 炮图标亮过又灭 = 炮打出去了, 返回 True。
        看到人形态 (没有炮) 或者等超时就松手返回 False, 由调用方走老办法。"""
        start = time.time()
        seen = False
        try:
            while time.time() - start < self.CANNON_HOLD_MAX:
                if self.task.in_team()[0]:
                    if self.cannon_ready():
                        seen = True
                    elif seen:
                        return True
                    elif self.in_human_form():
                        self.logger.info('hold cannon: human form, no cannon')
                        return False
                self.task.next_frame()
            self.logger.info(f'hold cannon: timed out (cannon icon seen: {seen})')
            return False
        finally:
            self.task.mouse_up()
            self.sleep(0.01, check_combat=False)

    def fire_liberation(self, char=None, time_out=None, fired=None, click=False, grace=None, extra=None):
        """连按 R 直到放出来, 演出期间按 F 接处决。达妮娅也用这个。

        放出来的判据: 演出开始 (队伍 HUD 消失), 或者 fired() 连续两次成立 (达妮娅 R2 不一定隐藏 HUD,
        传"R2 图标灭了")。不先判断"解放可用": 技能动画里那个检测常常不过, R 没转好时按了也不会有事。
        和框架的 click_liberation 一样设 task.in_liberation: 大招过场里锁不到敌人, 不设的话框架会判成脱战
        (2026-10-18 实测爱弥斯 R1 过场中被判脱战, 整轮重置); 按键间隔也不做战斗判定, 否则重新锁敌会卡 2~3 秒。
        """
        char = char or self
        time_out = self.LIB_TIME_OUT if time_out is None else time_out
        grace = self.LIB_GRACE if grace is None else grace
        start = time.time()
        presses = 0
        fired_count = 0
        self.task.in_liberation = True
        try:
            while time.time() - start < time_out:
                if presses and not self.task.in_team()[0]:
                    self.wait_lib_anim(char)
                    return True
                if presses and fired is not None:
                    fired_count = fired_count + 1 if fired() else 0
                    if fired_count >= self.LIB_FIRED_CHECKS:
                        char.logger.info(f'liberation fired after {presses} presses (HUD stayed)')
                        char.record_liberation_use()
                        return True
                    if fired_count:
                        # 看起来已经放出来了: 先别再按 R, 确认期间多按的 R 可能把刚转好的 R1 按出去
                        char.sleep(self.LIB_KEY_INTERVAL, check_combat=False)
                        continue
                # R、普攻 (click)、extra (达妮娅的 E) 一起连点, 不会冲突 (用户 2026-10-19);
                # 用户 "左键基本上就没停过", 原地连按 R 就是站着发呆
                # extra 放在 R 前面: R 一放出来, 下一轮开头就先查到, 不会再多按一下 E
                if extra is not None:
                    extra()
                char.send_liberation_key()
                presses += 1
                if click:
                    char.click()
                char.sleep(self.LIB_KEY_INTERVAL, check_combat=False)
            # 最后几下按出来的过场可能晚一点才开始: 留一小段时间再看, 期间仍然算"大招中"
            grace_start = time.time()
            last_click = 0
            while time.time() - grace_start < grace:
                if not self.task.in_team()[0]:
                    self.wait_lib_anim(char)
                    return True
                if click and time.time() - last_click >= self.A_INTERVAL:
                    char.click()
                    last_click = time.time()
                self.task.next_frame()
        finally:
            self.task.in_liberation = False
        char.logger.info(f'liberation did not fire after {presses} presses')
        return False

    def wait_lib_anim(self, char):
        """大招过场中 (队伍 HUD 消失): 设 in_liberation 等过场结束, 期间按 F 接处决。"""
        self.task.in_liberation = True
        anim_start = time.time()
        last_f = 0
        try:
            while not self.task.in_team()[0] and time.time() - anim_start < 8:
                if time.time() - anim_start >= 0.5 and time.time() - last_f >= 0.1:
                    self.task.send_key('f')
                    last_f = time.time()
                self.task.next_frame()
        finally:
            self.task.in_liberation = False
        char.add_freeze_duration(anim_start, time.time() - anim_start)
        char.record_liberation_use()

    def attack_until_lib(self, char=None, time_out=None, fired=None, tag='R1', extra=None):
        """放 R: 一直普攻, 边打边试 R, 放出来就返回 True。达妮娅的 R1、R2 也用这个。

        解放图标亮着 (能量满、冷却好了) 就每隔 R1_TRY_GAP 秒试按一下; 图标一直不亮也每隔 R1_BLIND_GAP 秒盲试。
        试 R 时 R 和普攻交替按, 不停手。
        fired: 传给 fire_liberation 的"放出来了"的额外判据 (达妮娅 R2 不隐藏 HUD)。
        extra: 每轮普攻前调用一次 (达妮娅等 R2 时顺手按 E)。
        不再"等图标亮了就原地连按": 2026-10-18 实测循环轴里图标亮了但冷却还差一点,
        达妮娅原地连按 1.6 秒没放出来就放弃, 后面那发 R 才是 R1, 整轮少了 R2 和延奏。
        """
        char = char or self
        time_out = self.R1_ENERGY_WAIT if time_out is None else time_out
        start = time.time()
        last_try = 0
        tries = 0
        while time.time() - start < time_out:
            if char is self:
                self.check_cannon()
            if tries and not self.task.in_team()[0]:
                # 前面按的 R 晚了一步才进过场: 当作放出来了, 不然普攻里的战斗判定会把过场判成脱战
                # (2026-10-18 实测爱弥斯 R1 这样放出来后被判脱战, 整轮重置成开场, 切去了达妮娅)
                self.wait_lib_anim(char)
                char.logger.info(f'{tag} after attacking {time.time() - start:.1f}s ({tries} tries, late cutscene)')
                return True
            now = time.time()
            if now - last_try >= self.R1_BLIND_GAP or \
                    (now - last_try >= self.R1_TRY_GAP and char.liberation_available()):
                tries += 1
                if self.fire_liberation(char, self.R1_TRY_TIME, fired=fired, click=True):
                    char.logger.info(f'{tag} after attacking {time.time() - start:.1f}s ({tries} tries)')
                    return True
                last_try = time.time()
            if extra is not None:
                extra()
            char.click()
            char.sleep(self.A_INTERVAL)
        char.logger.info(f'{tag} did not fire in {time_out:.0f}s ({tries} tries)')
        return False

    def fire_echo(self, char=None, time_out=None):
        """连按 Q 直到声骸进冷却, 达妮娅也用这个。Q 和普攻交替按, 不停手。

        用冷却判断而不是 echo_available: 技能/大招刚放完那会儿图标状态不准, 按一下就以为放了。"""
        char = char or self
        time_out = self.ECHO_TIME_OUT if time_out is None else time_out
        if self.task.has_cd('echo'):
            char.logger.info('Q already on cooldown before pressing')
        start = time.time()
        presses = 0
        while time.time() - start < time_out:
            if presses and self.task.has_cd('echo'):
                break
            char.send_echo_key()
            presses += 1
            char.sleep(0.05)
            char.click()
            char.sleep(0.05)
        char.record_echo_use()
        char.logger.info(f'Q after {presses} presses')

    def normal_e(self):
        """普通 E (切形态)。窗口亮着时按 E 会变成强化E, 这几个节点绝对不能打出强化E, 所以不按。"""
        if self.enhance_e_available():
            self.logger.info('skip normal E: enhance E window is lit')
            return False
        self.send_resonance_key()
        self.record_resonance_use()
        return True

    def attack_for(self, duration):
        start = time.time()
        while time.time() - start < duration:
            self.check_cannon()
            self.click()
            self.sleep(self.A_INTERVAL)

    def spin_until(self, cond, time_out, click=True):
        """边普攻边等条件成立, 成立时返回 True。"""
        start = time.time()
        last_click = 0
        while time.time() - start < time_out:
            if cond():
                return True
            self.check_cannon()
            if click and time.time() - last_click >= self.A_INTERVAL:
                self.click()
                last_click = time.time()
            self.sleep(0.03)
        return False

    def lib2_available(self):
        return bool(self.task.find_one('aemeath_lib2', threshold=0.7))

    def record_enhance_e(self):
        self.last_enhance_e = time.time()

    def enhance_e_available(self):
        return self.task.find_one('aemeath_e1', threshold=0.7) or self.task.find_one('aemeath_e2',
                                                                                     threshold=0.7)

    def enhance_e_ready(self):
        """强化E 图标亮着, 不是刚放失败的那个窗口, 而且没有确认处于"没锁到敌人"的状态。"""
        now = time.time()
        lit = bool(self.enhance_e_available())
        if lit:
            self.enhance_e_last_lit = now
        if self.enhance_e_blocked_until:
            window_over = now - self.enhance_e_last_lit >= self.ENHANCE_E_DROPOUT
            if not window_over and now < self.enhance_e_blocked_until:
                return False
            # 图标真的灭过 (窗口结束) 或者等够了, 下一个窗口可以再试
            self.enhance_e_blocked_until = 0
        return lit and self.enemy_locked()

    def wait_enhance_e_cast(self, time_out):
        """等强化E 放出来: 演出开始 (队伍 HUD 消失), 或者图标连续 ENHANCE_E_DROPOUT 秒认不出。"""
        start = time.time()
        dark_since = None
        while time.time() - start < time_out:
            if not self.task.in_team()[0]:
                return True
            if self.enhance_e_available():
                dark_since = None
            else:
                dark_since = dark_since or time.time()
                if time.time() - dark_since >= self.ENHANCE_E_DROPOUT:
                    return True
            self.task.next_frame()
        return False

    def enemy_locked(self):
        """只看锁敌图标, 不像 task.has_target 那样会等待或按 ESC。认不出来时当作锁到了。"""
        has_name, no_name = self.task.get_target_names()
        for box in (self.task.get_box_by_name(has_name).scale(1.1),
                    self.task.get_box_by_name('box_target_enemy_long'),
                    self.task.get_box_by_name('target_box_long2')):
            best = self.task.find_best_match_in_box(box, [has_name, no_name], threshold=0.6)
            if best:
                return best.name == has_name
        return True

    def try_enhance_e(self, prehold=False):
        """在强化E 窗口里按 E 并确认放出来了, 不像 click_resonance 那样 E/普攻 交替连发。

        只在图标还亮着 (还在窗口里) 时补按, 窗口外的 E 是普通 E, 会切形态。
        放出来的判据: 演出开始 (队伍 HUD 消失) 或者图标消失。
        这个窗口没放出来就等图标灭掉、下一个 A4 再试, 中间继续普攻。
        prehold: 演出末尾 (开始后 CANNON_PREHOLD_AFTER 秒, 或者演出结束时) 按住左键预输入开炮,
        返回 True 时左键是按住的, 调用方负责松开 (hold_cannon)。
        """
        cast = False
        presses = 0
        while presses < self.ENHANCE_E_PRESSES and self.enhance_e_available():
            self.send_resonance_key()
            presses += 1
            if self.wait_enhance_e_cast(self.ENHANCE_E_CONFIRM_TIME):
                cast = True
                break
        if not cast:
            e1 = self.task.find_one('aemeath_e1', threshold=0.5)
            e2 = self.task.find_one('aemeath_e2', threshold=0.5)
            self.logger.info(f'enhance E did not cast after {presses} presses, wait for the next window '
                             f'(e1={e1.confidence if e1 else 0:.2f} e2={e2.confidence if e2 else 0:.2f})')
            self.enhance_e_blocked_until = time.time() + self.ENHANCE_E_RETRY_COOLDOWN
            return False
        start = time.time()
        last_f = 0
        held = False
        # 演出期间队伍 HUD 隐藏、锁不到敌人, 和框架 click_resonance 一样设 in_liberation, 免得被判成脱战
        self.task.in_liberation = True
        try:
            while not self.task.in_team()[0] and time.time() - start < self.ENHANCE_E_ANIM_TIME_OUT:
                if prehold and not held and time.time() - start >= self.CANNON_PREHOLD_AFTER:
                    self.task.mouse_down()
                    held = True
                    self.logger.info(f'pre-input heavy {time.time() - start:.1f}s into the enhance E animation')
                if not held and time.time() - start >= 0.5 and time.time() - last_f >= 0.1:
                    self.task.send_key('f')
                    last_f = time.time()
                self.task.next_frame()
        finally:
            self.task.in_liberation = False
        if prehold and not held:
            self.task.mouse_down()
            self.logger.info(f'pre-input heavy at the end of the enhance E animation ({time.time() - start:.1f}s)')
        if time.time() - start > 0.1:
            self.add_freeze_duration(start, time.time() - start)
        self.record_resonance_use()
        self.record_enhance_e()
        return True

    def measure_enhance_e_window(self):
        """测强化E 窗口时长: 普攻到图标亮起 -> 停手 -> 记录到图标灭掉的时间。

        亮着时不能继续普攻, 否则窗口里再打出一个 A4 可能把窗口续上, 测出来偏长。
        每个窗口的误差不超过前后两帧的间隔, 日志里一并记下。
        """
        durations = []
        start = time.time()
        self.measure_start = start
        self.logger.info(f'measure enhance E window: start, {self.MEASURE_TIME:.0f}s')
        last_click = 0
        while time.time() - start < self.MEASURE_TIME:
            # 普攻每 0.1 秒点一下, 但每一帧都查图标, 亮起的时刻才准
            if not self.enhance_e_available():
                if time.time() - last_click >= 0.1:
                    self.click()
                    last_click = time.time()
                self.sleep(0.01)
                continue
            lit_at = time.time()
            lit_frame = self.task.frame
            lit_frame = lit_frame.copy() if lit_frame is not None else None
            form = 'human' if self.in_human_form() else 'mech'
            last_check = lit_at
            max_gap = 0.0
            # 短暂认不出 (< ENHANCE_E_DROPOUT) 不算灭, 这期间也不普攻
            dark_since = None
            dark_frame = None
            dropouts = 0
            while True:
                self.sleep(0.01)
                lit = self.enhance_e_available()
                now = time.time()
                max_gap = max(max_gap, now - last_check)
                last_check = now
                if lit:
                    if dark_since is not None:
                        dropouts += 1
                    dark_since = None
                elif dark_since is None:
                    dark_since = now
                    dark_frame = self.task.frame
                    dark_frame = dark_frame.copy() if dark_frame is not None else None
                elif now - dark_since >= self.ENHANCE_E_DROPOUT:
                    break
                if now - lit_at > self.MEASURE_LIT_TIME_OUT:
                    self.logger.warning('measure enhance E window: icon never went dark, '
                                        'the template is probably not the window icon')
                    return durations
            duration = dark_since - lit_at
            durations.append(duration)
            if len(durations) <= self.MEASURE_SAVE_WINDOWS:
                self.save_measure_frame(lit_frame, f'w{len(durations)}_lit')
                self.save_measure_frame(dark_frame, f'w{len(durations)}_dark')
            self.logger.info(f'measure enhance E window #{len(durations)}: lit {duration:.2f}s '
                             f'in {form} form, {dropouts} short dropouts ignored '
                             f'(frame gap up to {max_gap:.2f}s)')
        if durations:
            self.logger.info(f'measure enhance E window: {len(durations)} windows, '
                             f'min {min(durations):.2f}s avg {sum(durations) / len(durations):.2f}s '
                             f'max {max(durations):.2f}s')
        else:
            self.logger.info('measure enhance E window: icon never lit')
        return durations

    def save_measure_frame(self, frame, tag):
        """存一帧画面, 文件名带测量开始时间, 同一轮的图片排在一起。"""
        if frame is None:
            return
        try:
            import os
            import cv2
            folder = os.path.join(os.getcwd(), 'screenshots', 'aemeath_measure')
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, f'{time.strftime("%H-%M-%S", time.localtime(self.measure_start))}_{tag}.jpg')
            cv2.imwrite(path, frame, [cv2.IMWRITE_JPEG_QUALITY, 95])
            self.logger.info(f'measure enhance E window: saved {path}')
        except Exception as e:
            self.logger.warning(f'measure enhance E window: save frame failed {e}')

    def in_human_form(self):
        return bool(self.task.find_one('aemeath_human_heavy', threshold=0.7))

    def ensure_mech_form(self):
        """人形态时按一次 E 切到机兵形态, 再等强化重击图标出现。"""
        if not self.in_human_form():
            return True
        self.logger.info('in human form, press E to switch to mech form')
        self.send_resonance_key()
        if not self.task.wait_until(lambda: not self.in_human_form(), time_out=self.MECH_SWITCH_TIME_OUT):
            self.logger.warning('switch to mech form timed out')
            return False
        self.task.wait_until(self.has_long_action, time_out=self.MECH_HEAVY_WAIT)
        return True

    def heavy_wait_highlight_down(self):
        self.task.mouse_down()
        try:
            ret = self.task.wait_until(lambda: not self.has_long_action(), time_out=1.2)
        finally:
            self.task.mouse_up()
        self.sleep(0.01, check_combat=False)
        return ret

    def handle_heavy(self):
        if not self.has_long_action():
            return False
        if self.heavy_wait_highlight_down():
            # R2 亮着时直接接 R2 打断后摇, 不闪避
            if not self.lib2_available():
                self.dodge_cancel()
            return True
        return False

    def dodge_cancel(self):
        """重击打出后点按右键闪避, 打断后摇。"""
        self.sleep(self.HEAVY_DODGE_DELAY, check_combat=False)
        self.task.click(key='right', down_time=0.01)
        self.logger.debug('heavy attack dodge cancel')

    def on_combat_end(self, chars):
        # 留在场上, 下一轮战斗由爱弥斯重击开场
        self.logger.info('combat end, Aemeath stays on field for the next round')
